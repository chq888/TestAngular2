
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

/// The application that contains the DataGrid.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Employee Management',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1A73E8), // Professional blue color
          brightness: Brightness.light,
        ),
        textTheme: Typography.material2021().black,
        cardTheme: CardTheme(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        dialogTheme: DialogTheme(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28),
          ),
          elevation: 8,
        ),
      ),
      home: const MyHomePage(),
    );
  }
}

/// Employee class to hold employee details.
class Employee {
  Employee(this.id, this.name, this.designation, this.salary, this.roles, this.permissions);

  final int id;
  final String name;
  final String designation;
  final int salary;
  final List<String> roles;
  final List<String> permissions;
}

/// AsyncNotifier for managing employees and permissions.
class EmployeeNotifier extends AsyncNotifier<List<Employee>> {
  @override
  Future<List<Employee>> build() async {
    return getEmployeeData();
  }

  Future<void> reloadEmployees() async {
    state = const AsyncValue.loading(); // Set loading state
    try {
      final employees = await getEmployeeData();
      state = AsyncValue.data(employees); // Update state with fetched employees
    } catch (error, stack) {
      state = AsyncValue.error(error, stack); // Handle errors
    }
  }

  Future<void> clearEmployees() async {
    state = const AsyncValue.loading(); // Set loading state
    await Future.delayed(const Duration(milliseconds: 500));
    state = const AsyncValue.data([]); // Clear employees
  }
}

class PermissionsNotifier extends Notifier<AsyncValue<List<String>>> {
  int? employeeId;

  @override
  AsyncValue<List<String>> build() {
    return const AsyncValue.data([]); // Initial state
  }

  Future<void> setEmployeeId(int id) async {
    employeeId = id;
    state = const AsyncValue.loading(); // Set loading state
    try {
      final permissions = await fetchPermissions(id);
      state = AsyncValue.data(permissions); // Update state with fetched permissions
    } catch (error, stack) {
      state = AsyncValue.error(error, stack); // Handle errors
    }
  }

  Future<List<String>> fetchPermissions(int employeeId) async {
    // Simulate a delay for fetching data
    await Future.delayed(const Duration(seconds: 2));

    // Return permissions based on employee ID
    switch (employeeId) {
      case 10001:
        return ['Read', 'Write', 'Delete', 'Execute', 'Update', 'Create', 'Modify'];
      case 10002:
        return ['Read', 'Write', 'Execute'];
      case 10003:
        return ['Read', 'Write', 'Modify'];
      case 10004:
        return ['Read', 'Export', 'Import'];
      default:
        return ['No Permissions'];
    }
  }
}

final permissionsProvider = NotifierProvider<PermissionsNotifier, AsyncValue<List<String>>>(
  () => PermissionsNotifier(),
);
final employeeProvider = AsyncNotifierProvider<EmployeeNotifier, List<Employee>>(() {
  return EmployeeNotifier();
});

class MyHomePage extends ConsumerWidget {
  const MyHomePage({super.key});

@override
Widget build(BuildContext context, WidgetRef ref) {
  final employeeState = ref.watch(employeeProvider);

  return Scaffold(
    appBar: AppBar(
      title: const Text('Employee Management'),
      centerTitle: true,
      backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
    ),
    body: Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              FilledButton(
                onPressed: () {
                  ref.read(employeeProvider.notifier).clearEmployees();
                },
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  foregroundColor: Theme.of(context).colorScheme.onPrimary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                child: const Text('Clear All'),
              ),
              FilledButton(
                onPressed: () {
                  ref.read(employeeProvider.notifier).reloadEmployees();
                },
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.secondary,
                  foregroundColor: Theme.of(context).colorScheme.onSecondary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                child: const Text('Reload Grid'),
              ),
            ],
          ),
        ),
        Expanded(
          child: employeeState.when(
            data: (employees) {
              if (employees.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.info_outline, size: 30, color: Theme.of(context).colorScheme.onSurfaceVariant),
                      const SizedBox(height: 8),
                      Text(
                        'No Records Found',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                      ),
                    ],
                  ),
                );
              }

              final employeeDataSource = EmployeeDataSource(
                context: context,
                employeeData: employees,
                // Update the loading dialog in the onView callback
onView: (employee) async {
  try {
    // Create completer to handle cancellation
    final completer = Completer<bool>();
    bool cancelled = false;

    // Show loading dialog first
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28.0),
        ),
        backgroundColor: Theme.of(context).colorScheme.surface,
        elevation: 8,
        child: Container(
          padding: const EdgeInsets.all(24.0),
          constraints: const BoxConstraints(
            minWidth: 280.0,
            maxWidth: 360.0,
            minHeight: 200.0,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 64,
                height: 64,
                child: CircularProgressIndicator(
                  strokeWidth: 4,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Loading Permissions',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 16),
              Text(
                'Please wait while we fetch the permissions...',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () {
                  cancelled = true;
                  completer.complete(true); // Complete with cancelled = true
                  Navigator.of(dialogContext).pop();
                },
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.error,
                  foregroundColor: Theme.of(context).colorScheme.onError,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                icon: const Icon(Icons.close),
                label: const Text('Cancel'),
              ),
            ],
          ),
        ),
      ),
    );

    // Start fetching permissions
    ref.read(permissionsProvider.notifier).fetchPermissions(employee.id).then((permissions) {
      if (!cancelled && !completer.isCompleted) {
        completer.complete(false); // Complete with cancelled = false
        if (context.mounted) {
          Navigator.of(context).pop(); // Close loading dialog
          
          // Show content dialog
          showDialog(
            context: context,
            builder: (context) => _buildContentDialog(context, employee, permissions),
          );
        }
      }
    });

    // Wait for either cancellation or completion
    await completer.future;

  } catch (e) {
    if (context.mounted) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading permissions: $e')),
      );
    }
  }
},
              );

              return SfDataGrid(
                source: employeeDataSource,
                columnWidthMode: ColumnWidthMode.fill,
                columns: <GridColumn>[
                  GridColumn(
                    columnName: 'id',
                    label: Container(
                      padding: const EdgeInsets.all(16.0),
                      alignment: Alignment.center,
                      child: const Text('ID'),
                    ),
                  ),
                  GridColumn(
                    columnName: 'name',
                    label: Container(
                      padding: const EdgeInsets.all(8.0),
                      alignment: Alignment.center,
                      child: const Text('Name'),
                    ),
                  ),
                  GridColumn(
                    columnName: 'designation',
                    label: Container(
                      padding: const EdgeInsets.all(8.0),
                      alignment: Alignment.center,
                      child: const Text('Designation', overflow: TextOverflow.ellipsis),
                    ),
                  ),
                  GridColumn(
                    columnName: 'salary',
                    label: Container(
                      padding: const EdgeInsets.all(8.0),
                      alignment: Alignment.center,
                      child: const Text('Salary'),
                    ),
                  ),
                  GridColumn(
                    columnName: 'action',
                    label: Container(
                      padding: const EdgeInsets.all(8.0),
                      alignment: Alignment.center,
                      child: const Text('Action'),
                    ),
                  ),
                ],
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, stack) => Center(
              child: Text('Error: $error'),
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _buildContentDialog(BuildContext context, Employee employee, List<String> permissions) {
  return Dialog(
    backgroundColor: Theme.of(context).colorScheme.surface,
    elevation: 8,
    child: ConstrainedBox(
      constraints: BoxConstraints(
        minWidth: 400, // Minimum width
        maxWidth: MediaQuery.of(context).size.width * 0.5, // 90% of screen width
        minHeight: 400, // Minimum height
        maxHeight: MediaQuery.of(context).size.height * 0.5, // 90% of screen height
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Employee Information',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                  ),
                ),
              ],
            ),
          ),
          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Details Section
                 _buildInfoSection(
  context: context,
  title: 'Details',
  employee: employee,
),
                  const SizedBox(height: 24),
                  _buildRolesSection(context, employee.roles),
                  const SizedBox(height: 24),
                  _buildPermissionsSection(context, permissions),
                ],
              ),
            ),
          ),
          // Actions
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).pop(),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                  icon: const Icon(Icons.close),
                  label: const Text('Close'),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _buildRolesSection(BuildContext context, List<String> roles) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Roles',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
      const SizedBox(height: 16),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: roles.map((role) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondaryContainer,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.verified_user,
                size: 16,
                color: Theme.of(context).colorScheme.onSecondaryContainer,
              ),
              const SizedBox(width: 6),
              Text(
                role,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSecondaryContainer,
                      fontWeight: FontWeight.w500,
                    ),
              ),
            ],
          ),
        )).toList(),
      ),
    ],
  );
}
Widget _buildInfoSection({
  required BuildContext context,
  required String title,
  required Employee employee,
}) {
  return Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
        ),
        const SizedBox(height: 16),
        // First Row - ID and Name
        Row(
          children: [
            Expanded(
              child: _buildDetailRow(
                context,
                'ID',
                '#${employee.id}',
                isId: true,
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              child: _buildDetailRow(
                context,
                'Name',
                employee.name,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        // Second Row - Designation and Salary
        Row(
          children: [
            Expanded(
              child: _buildDetailRow(
                context,
                'Designation',
                employee.designation,
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              child: _buildDetailRow(
                context,
                'Salary',
                '\$${employee.salary.toStringAsFixed(2)}',
              ),
            ),
          ],
        ),
      ],
    ),
  );
}
Widget _buildDetailRow(BuildContext context, String label, String value, {bool isId = false}) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Text(
          value,
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w500,
                color: isId 
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurface,
                letterSpacing: isId ? 0.5 : null,
              ),
        ),
      ),
    ],
  );
}
Widget _buildPermissionsSection(BuildContext context, List<String> permissions) {
  final ScrollController scrollController = ScrollController();
  
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Permissions',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
      const SizedBox(height: 16),
      ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.2,
          minHeight: 100,
        ),
        child: ScrollbarTheme(
          data: ScrollbarThemeData(
            thumbColor: MaterialStateProperty.all(
              Theme.of(context).colorScheme.primary.withOpacity(0.5),
            ),
            thickness: MaterialStateProperty.all(8.0),
            radius: const Radius.circular(4.0),
          ),
          child: Scrollbar(
            thumbVisibility: true,
            controller: scrollController,
            child: ListView.builder( // Changed from ListView.separated
              controller: scrollController,
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.only(right: 16, left: 16, top: 8, bottom: 8),
              itemCount: permissions.length,
              itemBuilder: (context, index) {
                final permission = permissions[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.check_circle,
                          size: 16,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        permission,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color: Theme.of(context).colorScheme.onSurface,
                              fontWeight: FontWeight.w500,
                            ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    ],
  );
}
}


class EmployeeDataSource extends DataGridSource {
  final void Function(Employee) onView;
  final BuildContext context;

  EmployeeDataSource({
    required this.context,
    required List<Employee> employeeData,
    required this.onView,
  }) {
    _employeeData = employeeData.map<DataGridRow>(
      (employee) => DataGridRow(
        cells: [
          DataGridCell<int>(columnName: 'id', value: employee.id),
          DataGridCell<String>(columnName: 'name', value: employee.name),
          DataGridCell<String>(columnName: 'designation', value: employee.designation),
          DataGridCell<int>(columnName: 'salary', value: employee.salary),
          DataGridCell<Employee>(columnName: 'action', value: employee),
        ],
      ),
    ).toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: row.getCells().map<Widget>((cell) {
        if (cell.columnName == 'action') {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(8.0),
            child: IconButton(
              icon: Icon(Icons.visibility, color: Theme.of(context).colorScheme.primary),
              tooltip: 'View Details',
              onPressed: () {
                final employee = cell.value as Employee?;
                if (employee != null) {
                  onView(employee);
                }
              },
            ),
          );
        }
        return Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(8.0),
          child: Text(cell.value.toString()),
        );
      }).toList(),
    );
  }
}

/// Mock data for employees.
List<Employee> getEmployeeData() {
  return [
    Employee(10001, 'James', 'Project Lead', 20000, ['Admin'], ['Read', 'Write', 'Delete', 'Execute', 'Update', 'Create', 'Modify']),
    Employee(10002, 'Kathryn', 'Manager', 30000, ['Manager'], ['Read', 'Write']),
    Employee(10003, 'Lara', 'Developer', 15000, ['Developer'], ['Read', 'Write']),
    Employee(10004, 'Michael', 'Designer', 15000, ['Designer'], ['Read']),
  ];
}