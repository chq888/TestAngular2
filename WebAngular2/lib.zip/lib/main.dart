import 'package:equatable/equatable.dart';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Add this import for GoRouter and StatefulShellBranch
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:provider/provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


// Import your screen widgets
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // make navigation bar transparent
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  // make flutter draw behind navigation bar
   SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    runApp(
    const ProviderScope(
      child: MyApp (),
    ),
  );


}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    final userProfile = UserProfile(
  firstName: 'John',
  lastName: 'Doe',
  userName: 'johndoe',
  email: 'john.doe@example.com',
  age: 30,
  birthday: DateTime(1993, 5, 15),
  address: '123 Main St, City, Country',
  phone: '+1 234 567 8900',
  photoUrl: 'https://example.com/photo.jpg',
  companies: [
    CompanyInfo(
      name: 'Tech Corp',
      position: 'Senior Software Engineer',
      roles: List.generate(5, (index) => CompanyRole(
        role: 'Role ${index + 1}',
        permissions: List.generate(10, (i) => 'Permission ${i + 1}'),
      )),
    ),
    CompanyInfo(
      name: 'Innovate Inc',
      position: 'Technical Consultant',
      roles: List.generate(5, (index) => CompanyRole(
        role: 'Consultant Role ${index + 1}',
        permissions: List.generate(10, (i) => 'Consultant Permission ${i + 1}'),
      )),
    ),
  ],
);


    return MaterialApp(
      title: 'User Profile',
      theme: ThemeData(
        useMaterial3: true, // Enable Material 3
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        cardTheme: CardTheme(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          scrolledUnderElevation: 0,
        ),
        dividerTheme: const DividerThemeData(
          space: 20,
          thickness: 0.5,
        ),
      ),
      home: ProfileScreen(user: userProfile),
    );
  }
}


class UserProfile {
  final String firstName;
  final String lastName;
  final String userName;
  final String email;
  final int age;
  final DateTime birthday;
  final String address;
  final String phone;
  final String? photoUrl;
  final List<CompanyInfo> companies;

  const UserProfile({
    required this.firstName,
    required this.lastName,
    required this.userName,
    required this.email,
    required this.age,
    required this.birthday,
    required this.address,
    required this.phone,
    this.photoUrl,
    required this.companies,
  });

  String get fullName => '$firstName $lastName';
  
  // Get the current/primary company (first in the list)
  CompanyInfo get primaryCompany => companies.first;
}
class CompanyRole {
  final String role;
  final List<String> permissions;

  const CompanyRole({
    required this.role,
    required this.permissions,
  });
}

class CompanyInfo {
  final String name;
  final String position;
  final List<CompanyRole> roles;

  const CompanyInfo({
    required this.name,
    required this.position,
    required this.roles,
  });
}


class ProfileScreen extends StatefulWidget {
  final UserProfile user;

  const ProfileScreen({
    super.key,
    required this.user,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Track the currently selected company index
  int _selectedCompanyIndex = 0;
  
  // Getter for the user profile from widget
  UserProfile get user => widget.user;

  @override
  Widget build(BuildContext context) {
    // Get screen size for responsive design
    final screenSize = MediaQuery.of(context).size;
    final isSmallScreen = screenSize.width < 600;
    
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        toolbarHeight: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.zero,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildProfileHeader(context, isSmallScreen),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildUserDetailsSection(context, isSmallScreen),
                  const SizedBox(height: 24),
                  _buildCompanyRolesSection(context, isSmallScreen),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Profile header with photo, name and basic info - modern Material 3 design
  Widget _buildProfileHeader(BuildContext context, bool isSmallScreen) {
    return Column(
      children: [
        // Top section with background and avatar
        Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.bottomCenter,
          children: [
            // Gradient background container
            Container(
              width: double.infinity,
              height: isSmallScreen ? 160 : 180,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Theme.of(context).colorScheme.primary,
                    Theme.of(context).colorScheme.tertiary,
                  ],
                ),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(32),
                  bottomRight: Radius.circular(32),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Page title
                      Text(
                        'Profile',
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      // Action buttons
                      Row(
                        children: [
                          IconButton(
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.white.withOpacity(0.2),
                              foregroundColor: Colors.white,
                            ),
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Edit profile'))
                              );
                            },
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.white.withOpacity(0.2),
                              foregroundColor: Colors.white,
                            ),
                            icon: const Icon(Icons.settings_outlined),
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Settings'))
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            
            // Profile avatar
            Positioned(
              bottom: isSmallScreen ? -50 : -60,
              child: _buildAvatarBadge(context),
            ),
          ],
        ),
        
        // User info section below the avatar
        Padding(
          padding: EdgeInsets.only(
            top: isSmallScreen ? 60 : 70,
            bottom: 10,
            left: 20,
            right: 20,
          ),
          child: Column(
            children: [
              // User name and username
              Text(
                user.fullName,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                '@${user.userName}',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              
              // Company info pill
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.business_rounded,
                      size: 20,
                      color: Theme.of(context).colorScheme.onSecondaryContainer,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${user.primaryCompany.name} • ${user.primaryCompany.position}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w500,
                            color: Theme.of(context).colorScheme.onSecondaryContainer,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              
              // Contact info chips
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  _buildContactChip(context, user.email, Icons.email_rounded),
                  _buildContactChip(context, user.phone, Icons.phone_rounded),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Avatar badge with animation effects
  Widget _buildAvatarBadge(BuildContext context) {
    final bool isSmallScreen = MediaQuery.of(context).size.width < 600;
    
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: Colors.white,
          width: 5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 12,
            spreadRadius: 2,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: CircleAvatar(
        radius: isSmallScreen ? 50 : 60,
        backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
        backgroundImage: user.photoUrl != null
            ? NetworkImage(user.photoUrl!)
            : null,
        child: user.photoUrl == null
            ? Text(
                user.firstName[0] + user.lastName[0],
                style: TextStyle(
                  fontSize: isSmallScreen ? 36 : 42,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              )
            : null,
      ),
    );
  }

  // Contact info chip for a cleaner display
  Widget _buildContactChip(BuildContext context, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 3,
            spreadRadius: 0,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 18,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // User details section with all personal information
  Widget _buildUserDetailsSection(BuildContext context, bool isSmallScreen) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(context, 'Personal Information', Icons.person_outline),
            const SizedBox(height: 20),
            isSmallScreen
                ? Column(
                    children: _buildDetailItems(context),
                  )
                : Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          children: _buildDetailItems(context).sublist(0, 4),
                        ),
                      ),
                      const SizedBox(width: 24),
                      Expanded(
                        child: Column(
                          children: _buildDetailItems(context).sublist(4),
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  // Generate list of detail items for user information
  List<Widget> _buildDetailItems(BuildContext context) {
    final formatter = DateFormat('MMMM d, yyyy');
    
    final details = [
      {'First Name': user.firstName},
      {'Last Name': user.lastName},
      {'Username': user.userName},
      {'Email': user.email},
      {'Age': user.age.toString()},
      {'Birthday': formatter.format(user.birthday)},
      {'Address': user.address},
      {'Phone': user.phone},
    ];
    
    return details.map((detail) => _buildDetailItem(context, detail)).toList();
  }

  // Individual detail item with label and value
  Widget _buildDetailItem(BuildContext context, Map<String, String> detail) {
    final entry = detail.entries.first;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            entry.key,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            entry.value,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
          ),
          const SizedBox(height: 8),
          Divider(height: 1, thickness: 0.5),
        ],
      ),
    );
  }

  // Section header with icon and title
  Widget _buildSectionHeader(BuildContext context, String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).colorScheme.primary,
            size: 22,
          ),
        ),
        const SizedBox(width: 16),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                letterSpacing: -0.5,
              ),
        ),
      ],
    );
  }



  // Company roles section with expandable role cards
  Widget _buildCompanyRolesSection(BuildContext context, bool isSmallScreen) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCompanySelector(context),
            const SizedBox(height: 20),
            // Selected company roles and permissions
            _buildCompanySection(context, user.companies[_selectedCompanyIndex], isSmallScreen),
          ],
        ),
      ),
    );
  }
  
  // Company selector with segmented buttons
  Widget _buildCompanySelector(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Company Information',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
            ),
            const Spacer(),
            // Company segmented selector - moved next to the badge
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: user.companies.asMap().entries.map((entry) {
                final index = entry.key;
                final company = entry.value;
                return ButtonSegment<int>(
                  value: index,
                  label: Text(company.name, style: const TextStyle(fontSize: 13)),
                  icon: const Icon(Icons.business_outlined, size: 14),
                );
              }).toList(),
              selected: {_selectedCompanyIndex},
              onSelectionChanged: (Set<int> selection) {
                setState(() {
                  _selectedCompanyIndex = selection.first;
                });
              },
              style: ButtonStyle(
                visualDensity: VisualDensity.compact,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                backgroundColor: MaterialStateProperty.resolveWith<Color?>(
                  (Set<MaterialState> states) {
                    if (states.contains(MaterialState.selected)) {
                      return Theme.of(context).colorScheme.primaryContainer;
                    }
                    return Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.4);
                  },
                ),
                foregroundColor: MaterialStateProperty.resolveWith<Color?>(
                  (Set<MaterialState> states) {
                    if (states.contains(MaterialState.selected)) {
                      return Theme.of(context).colorScheme.onPrimaryContainer;
                    }
                    return Theme.of(context).colorScheme.onSurfaceVariant;
                  },
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Company count badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                '${user.companies.length}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).colorScheme.primary,
                    ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        
        // Animation indicator
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: 4,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.tertiary,
              ],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }
  
  // Individual company section with its roles and permissions separated
  Widget _buildCompanySection(BuildContext context, CompanyInfo company, bool isSmallScreen) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Company info badge
        Container(
          margin: const EdgeInsets.only(bottom: 24),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.5),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Theme.of(context).colorScheme.secondary.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.badge_outlined,
                color: Theme.of(context).colorScheme.secondary,
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  company.position,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).colorScheme.onSecondaryContainer,
                      ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${company.roles.length} roles',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                ),
              ),
            ],
          ),
        ),
        
        // Roles Section
        Text(
          'Assigned Roles',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface,
              ),
        ),
        const SizedBox(height: 12),
        _buildRolesList(context, company.roles),
        
        const SizedBox(height: 24),
        
        // Permissions Section
        Text(
          'All Permissions',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface,
              ),
        ),
        const SizedBox(height: 12),
        _buildAllPermissionsGrid(context, company.roles, isSmallScreen),
      ],
    );
  }

  // Role chip for the roles list
  Widget _buildRoleChip(BuildContext context, CompanyRole role) {
    return Container(
      margin: const EdgeInsets.only(right: 8, bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.workspace_premium,
            color: Theme.of(context).colorScheme.primary,
            size: 16,
          ),
          const SizedBox(width: 8),
          Text(
            role.role,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).colorScheme.primary,
                ),
          ),
        ],
      ),
    );
  }

  // Wrap widget for roles list
  Widget _buildRolesList(BuildContext context, List<CompanyRole> roles) {
    return Wrap(
      spacing: 0,
      runSpacing: 0,
      children: roles.map((role) => _buildRoleChip(context, role)).toList(),
    );
  }
  
  // Grid of permissions with responsive columns
  Widget _buildPermissionsGrid(BuildContext context, List<String> permissions, bool isSmallScreen) {
    final columns = isSmallScreen ? 2 : 3;
    
    // Calculate the aspect ratio to ensure items are 30px high
    // First get available width after padding
    final availableWidth = MediaQuery.of(context).size.width - 64; // accounting for padding
    // Width per item
    final itemWidth = (availableWidth / columns) - 8; // subtracting crossAxisSpacing
    // Calculate aspect ratio (width / height)
    final aspectRatio = itemWidth / 30.0; // 30px height
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        childAspectRatio: aspectRatio,  // Dynamic aspect ratio for 30px height
        mainAxisSpacing: 6,   // Reduced spacing
        crossAxisSpacing: 8,  // Reduced spacing
      ),
      itemCount: permissions.length,
      itemBuilder: (context, index) {
        return _buildPermissionItem(context, permissions[index]);
      },
    );
  }
  
  // Collect all permissions from all roles and display them in a grid
  Widget _buildAllPermissionsGrid(BuildContext context, List<CompanyRole> roles, bool isSmallScreen) {
    // Collect all unique permissions from all roles
    final Set<String> allPermissions = {};
    for (final role in roles) {
      allPermissions.addAll(role.permissions);
    }
    
    // Convert to a sorted list
    final permissions = allPermissions.toList()..sort();
    
    return _buildPermissionsGrid(context, permissions, isSmallScreen);
  }

  // Individual permission item with check icon
  Widget _buildPermissionItem(BuildContext context, String permission) {
    return Container(
      height: 30, // Fixed height of 30px
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(8),  // More rounded corners for Material 3
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.3),
          width: 0.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center, // Center vertically
        children: [
          Icon(
            Icons.check_circle_rounded, // More rounded icon for Material 3
            color: Theme.of(context).colorScheme.primary,
            size: 14,  // Slightly larger for better visibility
          ),
          const SizedBox(width: 6),  // Slightly more spacing
          Expanded(
            child: Text(
              permission,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontSize: 12,  // Smaller text
                fontWeight: FontWeight.w500, // Medium weight for better visibility
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }
}
