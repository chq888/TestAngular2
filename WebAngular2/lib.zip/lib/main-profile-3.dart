import 'package:equatable/equatable.dart';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Add this import for GoRouter and StatefulShellBranch
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:provider/provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


// Import your screen widgets
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // make navigation bar transparent
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  // make flutter draw behind navigation bar
   SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    runApp(
    const ProviderScope(
      child: MyApp (),
    ),
  );


}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    final userProfile = UserProfile(
  firstName: 'John',
  lastName: 'Doe',
  userName: 'johndoe',
  email: 'john.doe@example.com',
  age: 30,
  birthday: DateTime(1993, 5, 15),
  address: '123 Main St, City, Country',
  phone: '+1 234 567 8900',
  photoUrl: 'https://example.com/photo.jpg',
  company: CompanyInfo(
    name: 'Tech Corp',
    position: 'Senior Software Engineer',
    roles: List.generate(10, (index) => CompanyRole(
      role: 'Role ${index + 1}',
      permissions: List.generate(20, (i) => 'Permission ${i + 1}'),
    )),
  ),
);


    return MaterialApp(
      title: 'Syncfusion DataGrid Demo',
      theme: ThemeData(
        useMaterial3: true, // Enable Material 3
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue), // Use Material 3 color scheme
        textTheme: Typography.material2021().black, // Use Material 3 typography
      ),
      home: ProfileScreen(user: userProfile),
    );
  }
}


class UserProfile {
  final String firstName;
  final String lastName;
  final String userName;
  final String email;
  final int age;
  final DateTime birthday;
  final String address;
  final String phone;
  final String? photoUrl;
  final CompanyInfo company;

  const UserProfile({
    required this.firstName,
    required this.lastName,
    required this.userName,
    required this.email,
    required this.age,
    required this.birthday,
    required this.address,
    required this.phone,
    this.photoUrl,
        required this.company,

  });

  String get fullName => '$firstName $lastName';
}
class CompanyRole {
  final String role;
  final List<String> permissions;

  const CompanyRole({
    required this.role,
    required this.permissions,
  });
}

class CompanyInfo {
  final String name;
  final String position;
  final List<CompanyRole> roles;

  const CompanyInfo({
    required this.name,
    required this.position,
    required this.roles,
  });
}


class ProfileScreen extends StatelessWidget {
  final UserProfile user;

  const ProfileScreen({
    super.key,
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildProfileHeader(context),
          const SizedBox(height: 24),
          _buildDetailsSection(context),
          const SizedBox(height: 24),
          _buildCompanyRolesSection(context),
        ],
      ),
    ),
    );
  }
Widget _buildProfileHeader(BuildContext context) {
  final isSmallScreen = MediaQuery.of(context).size.width < 600;
  return Card(
    elevation: 3,
    shadowColor: Colors.black12,
    clipBehavior: Clip.antiAlias,
    margin: EdgeInsets.zero,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    child: Stack(
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Theme.of(context).colorScheme.primaryContainer.withOpacity(0.18),
                  Theme.of(context).colorScheme.surface,
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: isSmallScreen ? 18.0 : 28.0,
            vertical: isSmallScreen ? 22.0 : 30.0,
          ),
          child: IntrinsicHeight(
            child: Row(
              children: [
                _buildAvatar(context, isSmallScreen),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.fullName,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          fontSize: isSmallScreen ? 22 : 26,
                          letterSpacing: -0.5,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        user.email,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.w500,
                          fontSize: isSmallScreen ? 13.5 : 15,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 10,
                        runSpacing: 8,
                        children: [
                          _buildInfoChip(
                            context, 
                            user.company.name,
                            backgroundColor: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.35),
                          ),
                          _buildInfoChip(
                            context, 
                            user.company.position,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _buildDetailsSection(BuildContext context) {
  final details = [
    {'label': 'Username', 'value': user.userName},
    {'label': 'Age', 'value': '${user.age} years'},
    {'label': 'Birthday', 'value': DateFormat('MMM d, y').format(user.birthday)},
    {'label': 'Phone', 'value': user.phone},
    {'label': 'Address', 'value': user.address},
  ];

  return Card(
    elevation: 2,
    margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 0),
    color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.22),
    shadowColor: Colors.black12,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20),
      side: BorderSide(
        color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.18),
        width: 0.8,
      ),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
            context,
            title: 'Personal Information',
            icon: Icons.person_outline,
          ),
          const Divider(height: 28, thickness: 0.7),
          LayoutBuilder(
            builder: (context, constraints) {
              int columns = (constraints.maxWidth > 900)
                  ? 3
                  : (constraints.maxWidth > 600)
                      ? 2
                      : 1;
              double availableWidth = constraints.maxWidth - 24;
              double itemWidth = (availableWidth - (columns - 1) * 8) / columns;
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: details.map((detail) {
                    return SizedBox(
                      width: itemWidth,
                      height: 84,
                      child: _buildDetailItem(context, detail),
                    );
                  }).toList(),
                ),
              );
            },
          ),
        ],
      ),
    ),
  );
}
Widget _buildDetailItem(BuildContext context, Map<String, String> detail) {
  return SizedBox(
    height: 84, // Slightly increased for better spacing
    child: Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        splashColor: Theme.of(context).colorScheme.primary.withOpacity(0.08),
        highlightColor: Colors.transparent,
        onTap: () {}, // For visual feedback only
        child: Card(
          elevation: 0,
          margin: EdgeInsets.zero,
          color: Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: BorderSide(
              color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.12),
              width: 0.6,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  detail['label']!.toUpperCase(),
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  detail['value']!,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).colorScheme.onSurface,
                        height: 1.1,
                      ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
Widget _buildProfileChip(BuildContext context, String label, IconData icon) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          size: 14,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            fontSize: 12,
          ),
        ),
      ],
    ),
  );
}
Widget _buildAvatar(BuildContext context, bool isSmallScreen) {
  return Stack(
    children: [
      Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            width: 3,
          ),
        ),
        child: CircleAvatar(
          radius: isSmallScreen ? 36 : 44,
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
          backgroundImage: user.photoUrl != null 
              ? NetworkImage(user.photoUrl!) 
              : null,
          child: user.photoUrl == null 
              ? Text(
                  user.firstName[0] + user.lastName[0],
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    fontSize: isSmallScreen ? 24 : 28,
                  ),
                )
              : null,
        ),
      ),
      Positioned(
        right: 0,
        bottom: 0,
        child: Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Theme.of(context).colorScheme.shadow.withOpacity(0.1),
                blurRadius: 4,
              ),
            ],
          ),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.camera_alt_outlined,
              size: isSmallScreen ? 12 : 14,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
        ),
      ),
    ],
  );
}

Widget _buildInfoChip(
  BuildContext context, 
  String label, 
  {Color? backgroundColor}
) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: backgroundColor ?? Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(
        color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.2),
        width: 0.5,
      ),
    ),
    child: Text(
      label,
      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
        color: Theme.of(context).colorScheme.onSurface,
        fontSize: 13,
        fontWeight: FontWeight.w500,
      ),
    ),
  );
}

Widget _buildSectionHeader(
  BuildContext context, {
  required String title,
  required IconData icon,
}) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(8, 12, 8, 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  fontSize: 16.5,
                  letterSpacing: 0.1,
                ),
          ),
        ),
        Container(
          width: 26,
          height: 26,
          alignment: Alignment.center,
          child: Icon(
            icon,
            size: 16,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
      ],
    ),
  );
}
Widget _buildCompanyRolesSection(BuildContext context) {
  return Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user.company.name,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user.company.position,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
              CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                child: Text(
                  user.company.name[0],
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
                ),
              ),
            ],
          ),
          const Divider(height: 32),
          Text(
            'Roles & Permissions',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 16),
          ...user.company.roles.map((role) => _buildRoleCard(context, role)),
        ],
      ),
    ),
  );
}
Widget _buildRoleCard(BuildContext context, CompanyRole role) {
  return Card(
    margin: const EdgeInsets.only(bottom: 8),
    elevation: 0,
    clipBehavior: Clip.antiAlias, // Add smooth clipping for expansion
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8),
      side: BorderSide(
        color: Theme.of(context).colorScheme.outlineVariant,
        width: 0.5, // Thinner border
      ),
    ),
    child: ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), // Reduced padding
      childrenPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(6), // Smaller icon container
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(
          Icons.workspace_premium,
          color: Theme.of(context).colorScheme.primary,
          size: 18, // Smaller icon
        ),
      ),
      title: Text(
        role.role,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w500,
          fontSize: 14, // Smaller text
        ),
      ),
      subtitle: Text(
        '${role.permissions.length} permissions',
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
          fontSize: 12, // Smaller text
        ),
      ),
      children: [
        Divider(
          height: 1,
          thickness: 0.5, // Thinner divider
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
        LayoutBuilder(
          builder: (context, constraints) {
            final columns = constraints.maxWidth > 600 ? 3 : 2;
            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                childAspectRatio: 8,
                mainAxisSpacing: 6,
                crossAxisSpacing: 12,
              ),
              itemCount: role.permissions.length,
              itemBuilder: (context, index) {
                final permission = role.permissions[index];
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), // Reduced padding
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceVariant.withAlpha(50),
                    borderRadius: BorderRadius.circular(4), // Smaller radius
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.check_circle,
                        color: Theme.of(context).colorScheme.primary,
                        size: 14, // Smaller icon
                      ),
                      const SizedBox(width: 6), // Reduced spacing
                      Expanded(
                        child: Text(
                          permission,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontSize: 12, // Smaller text
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ],
    ),
  );
}


}// Example usage in your app
