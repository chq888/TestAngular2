import 'package:equatable/equatable.dart';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Add this import for GoRouter and StatefulShellBranch
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:provider/provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


// Import your screen widgets
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // make navigation bar transparent
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  // make flutter draw behind navigation bar
   SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    runApp(
    const ProviderScope(
      child: MyApp (),
    ),
  );


}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    final userProfile = UserProfile(
  firstName: 'John',
  lastName: 'Doe',
  userName: 'johndoe',
  email: 'john.doe@example.com',
  age: 30,
  birthday: DateTime(1993, 5, 15),
  address: '123 Main St, City, Country',
  phone: '+1 234 567 8900',
  photoUrl: 'https://example.com/photo.jpg',
  companies: [
    CompanyInfo(
      name: 'Tech Corp',
      position: 'Senior Software Engineer',
      roles: List.generate(5, (index) => CompanyRole(
        role: 'Role ${index + 1}',
        permissions: List.generate(10, (i) => 'Permission ${i + 1}'),
      )),
    ),
    CompanyInfo(
      name: 'Innovate Inc',
      position: 'Technical Consultant',
      roles: List.generate(5, (index) => CompanyRole(
        role: 'Consultant Role ${index + 1}',
        permissions: List.generate(10, (i) => 'Consultant Permission ${i + 1}'),
      )),
    ),
  ],
);


    return MaterialApp(
      title: 'User Profile',
      theme: ThemeData(
        useMaterial3: true, // Enable Material 3
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        cardTheme: CardTheme(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          scrolledUnderElevation: 0,
        ),
        dividerTheme: const DividerThemeData(
          space: 20,
          thickness: 0.5,
        ),
      ),
      home: ProfileScreen(user: userProfile),
    );
  }
}


class UserProfile {
  final String firstName;
  final String lastName;
  final String userName;
  final String email;
  final int age;
  final DateTime birthday;
  final String address;
  final String phone;
  final String? photoUrl;
  final List<CompanyInfo> companies;

  const UserProfile({
    required this.firstName,
    required this.lastName,
    required this.userName,
    required this.email,
    required this.age,
    required this.birthday,
    required this.address,
    required this.phone,
    this.photoUrl,
    required this.companies,
  });

  String get fullName => '$firstName $lastName';
  
  // Get the current/primary company (first in the list)
  CompanyInfo get primaryCompany => companies.first;
}
class CompanyRole {
  final String role;
  final List<String> permissions;

  const CompanyRole({
    required this.role,
    required this.permissions,
  });
}

class CompanyInfo {
  final String name;
  final String position;
  final List<CompanyRole> roles;

  const CompanyInfo({
    required this.name,
    required this.position,
    required this.roles,
  });
}


class ProfileScreen extends StatefulWidget {
  final UserProfile user;

  const ProfileScreen({
    super.key,
    required this.user,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Track the currently selected company index
  int _selectedCompanyIndex = 0;
  
  // Getter for the user profile from widget
  UserProfile get user => widget.user;

  @override
  Widget build(BuildContext context) {
    // Get screen size for responsive design
    final screenSize = MediaQuery.of(context).size;
    final isSmallScreen = screenSize.width < 600;
    
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        toolbarHeight: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.zero,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildProfileHeader(context, isSmallScreen),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildUserDetailsSection(context, isSmallScreen),
                  const SizedBox(height: 24),
                  _buildCompanyRolesSection(context, isSmallScreen),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Profile header with photo, name and basic info
  Widget _buildProfileHeader(BuildContext context, bool isSmallScreen) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // Background card with gradient
        Card(
          margin: EdgeInsets.only(bottom: isSmallScreen ? 90 : 40),
          elevation: 0,
          clipBehavior: Clip.antiAlias,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(24),
              bottomRight: Radius.circular(24),
            ),
          ),
          child: Container(
            width: double.infinity,
            height: isSmallScreen ? 160 : 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Theme.of(context).colorScheme.tertiary,
                ],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Profile',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, color: Colors.white),
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Edit profile'))
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.settings_outlined, color: Colors.white),
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Settings'))
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        
        // Profile card with avatar and info
        Positioned(
          left: 0,
          right: 0,
          top: isSmallScreen ? 100 : 120,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Card(
              elevation: 3,
              shadowColor: Colors.black38,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: isSmallScreen
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _buildAvatar(context),
                          const SizedBox(height: 20),
                          _buildHeaderInfo(context),
                        ],
                      )
                    : Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _buildAvatar(context),
                          const SizedBox(width: 24),
                          Expanded(child: _buildHeaderInfo(context)),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Avatar widget with placeholder if no photo URL
  Widget _buildAvatar(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: Theme.of(context).colorScheme.surface,
          width: 4,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            spreadRadius: 2,
          ),
        ],
      ),
      child: CircleAvatar(
        radius: 45,
        backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
        backgroundImage: user.photoUrl != null
            ? NetworkImage(user.photoUrl!)
            : null,
        child: user.photoUrl == null
            ? Text(
                user.firstName[0] + user.lastName[0],
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              )
            : null,
      ),
    );
  }

  // Header info with name, username, and position
  Widget _buildHeaderInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          user.fullName,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          '@${user.userName}',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.business,
                size: 16,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  '${user.primaryCompany.name} • ${user.primaryCompany.position}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _buildInfoChip(context, user.email, Icons.email_outlined),
            _buildInfoChip(context, user.phone, Icons.phone_outlined),
          ],
        ),
      ],
    );
  }

  // User details section with all personal information
  Widget _buildUserDetailsSection(BuildContext context, bool isSmallScreen) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(context, 'Personal Information', Icons.person_outline),
            const SizedBox(height: 20),
            isSmallScreen
                ? Column(
                    children: _buildDetailItems(context),
                  )
                : Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          children: _buildDetailItems(context).sublist(0, 4),
                        ),
                      ),
                      const SizedBox(width: 24),
                      Expanded(
                        child: Column(
                          children: _buildDetailItems(context).sublist(4),
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  // Generate list of detail items for user information
  List<Widget> _buildDetailItems(BuildContext context) {
    final formatter = DateFormat('MMMM d, yyyy');
    
    final details = [
      {'First Name': user.firstName},
      {'Last Name': user.lastName},
      {'Username': user.userName},
      {'Email': user.email},
      {'Age': user.age.toString()},
      {'Birthday': formatter.format(user.birthday)},
      {'Address': user.address},
      {'Phone': user.phone},
    ];
    
    return details.map((detail) => _buildDetailItem(context, detail)).toList();
  }

  // Individual detail item with label and value
  Widget _buildDetailItem(BuildContext context, Map<String, String> detail) {
    final entry = detail.entries.first;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            entry.key,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            entry.value,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
          ),
          const SizedBox(height: 8),
          Divider(height: 1, thickness: 0.5),
        ],
      ),
    );
  }

  // Section header with icon and title
  Widget _buildSectionHeader(BuildContext context, String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).colorScheme.primary,
            size: 22,
          ),
        ),
        const SizedBox(width: 16),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                letterSpacing: -0.5,
              ),
        ),
      ],
    );
  }

  // Info chip for contact information
  Widget _buildInfoChip(BuildContext context, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 3,
            spreadRadius: 0,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 16,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w500,
                ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // Company roles section with expandable role cards
  Widget _buildCompanyRolesSection(BuildContext context, bool isSmallScreen) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCompanySelector(context),
            const SizedBox(height: 20),
            // Selected company roles and permissions
            _buildCompanySection(context, user.companies[_selectedCompanyIndex], isSmallScreen),
          ],
        ),
      ),
    );
  }
  
  // Company selector with tabs
  Widget _buildCompanySelector(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Company Information',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
            ),
            const Spacer(),
            // Company selector dropdown
            Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.4),
                borderRadius: BorderRadius.circular(20),
              ),
              child: DropdownButton<int>(
                value: _selectedCompanyIndex,
                icon: const Icon(Icons.arrow_drop_down_rounded),
                elevation: 1,
                underline: const SizedBox(),
                borderRadius: BorderRadius.circular(12),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                onChanged: (int? index) {
                  if (index != null) {
                    setState(() {
                      _selectedCompanyIndex = index;
                    });
                  }
                },
                items: user.companies.asMap().entries.map((entry) {
                  final index = entry.key;
                  final company = entry.value;
                  return DropdownMenuItem<int>(
                    value: index,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.business_outlined,
                          size: 16,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 8),
                        Text(company.name),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        // Company indicator
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: 4,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.tertiary,
              ],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }
  
  // Individual company section with its roles
  Widget _buildCompanySection(BuildContext context, CompanyInfo company, bool isSmallScreen) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Company info badge
        Container(
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.5),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Theme.of(context).colorScheme.secondary.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.badge_outlined,
                color: Theme.of(context).colorScheme.secondary,
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  company.position,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).colorScheme.onSecondaryContainer,
                      ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${company.roles.length} roles',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                ),
              ),
            ],
          ),
        ),
        // Roles list with animation
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          switchInCurve: Curves.easeInOut,
          switchOutCurve: Curves.easeInOut,
          transitionBuilder: (Widget child, Animation<double> animation) {
            return FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0.05, 0),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              ),
            );
          },
          child: Column(
            key: ValueKey<String>(company.name), // Key for animation
            children: company.roles.map((role) => _buildRoleCard(context, role, isSmallScreen)).toList(),
          ),
        ),
      ],
    );
  }

  // Individual role card with expandable permissions list
  Widget _buildRoleCard(BuildContext context, CompanyRole role, bool isSmallScreen) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
          expansionTileTheme: ExpansionTileThemeData(
            backgroundColor: Theme.of(context).colorScheme.surface,
            collapsedBackgroundColor: Theme.of(context).colorScheme.surface,
          ),
        ),
        child: ExpansionTile(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          childrenPadding: EdgeInsets.zero,
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.workspace_premium,
              color: Theme.of(context).colorScheme.primary,
              size: 18,
            ),
          ),
          title: Text(
            role.role,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                ),
          ),
          subtitle: Text(
            '${role.permissions.length} permissions',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontSize: 12,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          trailing: Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.keyboard_arrow_down_rounded,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ),
          children: [
            Divider(height: 1, thickness: 0.5, color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.3)),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: _buildPermissionsGrid(context, role.permissions, isSmallScreen),
            ),
          ],
        ),
      ),
    );
  }

  // Grid of permissions with responsive columns
  Widget _buildPermissionsGrid(BuildContext context, List<String> permissions, bool isSmallScreen) {
    final columns = isSmallScreen ? 2 : 3;
    
    // Calculate the aspect ratio to ensure items are 30px high
    // First get available width after padding
    final availableWidth = MediaQuery.of(context).size.width - 64; // accounting for padding
    // Width per item
    final itemWidth = (availableWidth / columns) - 8; // subtracting crossAxisSpacing
    // Calculate aspect ratio (width / height)
    final aspectRatio = itemWidth / 30.0; // 30px height
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        childAspectRatio: aspectRatio,  // Dynamic aspect ratio for 30px height
        mainAxisSpacing: 6,   // Reduced spacing
        crossAxisSpacing: 8,  // Reduced spacing
      ),
      itemCount: permissions.length,
      itemBuilder: (context, index) {
        return _buildPermissionItem(context, permissions[index]);
      },
    );
  }

  // Individual permission item with check icon
  Widget _buildPermissionItem(BuildContext context, String permission) {
    return Container(
      height: 30, // Fixed height of 30px
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(8),  // More rounded corners for Material 3
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.3),
          width: 0.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center, // Center vertically
        children: [
          Icon(
            Icons.check_circle_rounded, // More rounded icon for Material 3
            color: Theme.of(context).colorScheme.primary,
            size: 14,  // Slightly larger for better visibility
          ),
          const SizedBox(width: 4),  // Reduced spacing
          Expanded(
            child: Text(
              permission,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontSize: 12,  // Smaller text
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }
}
