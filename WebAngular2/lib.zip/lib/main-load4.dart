
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';


/// The application that contains the DataGrid.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Employee Management',
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.light, // Uses system theme settings
      home: const MyHomePage(),
    );
  }
}
class EmployeeDialog extends StatelessWidget {
  final Employee employee;
  final List<String> permissions;

  const EmployeeDialog({
    super.key,
    required this.employee,
    required this.permissions,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Theme.of(context).colorScheme.surface,
      elevation: 8,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minWidth: 500,
          maxWidth: MediaQuery.of(context).size.width * 0.5,
          minHeight: 500,
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: Column(
          children: [
            _buildHeader(context),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildInfoSection(context),
                    const SizedBox(height: 24),
                    _buildRolesSection(context),
                    const SizedBox(height: 24),
                    _buildPermissionsSection(context),
                  ],
                ),
              ),
            ),
            _buildActions(context),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Employee Information',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoSection(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withAlpha(77),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Details',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildDetailRow(
                  context,
                  'ID',
                  '#${employee.id}',
                  isId: true,
                ),
              ),
              const SizedBox(width: 24),
              Expanded(
                child: _buildDetailRow(
                  context,
                  'Name',
                  employee.name,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildDetailRow(
                  context,
                  'Designation',
                  employee.designation,
                ),
              ),
              const SizedBox(width: 24),
              Expanded(
                child: _buildDetailRow(
                  context,
                  'Salary',
                  '\$${employee.salary.toStringAsFixed(2)}',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(BuildContext context, String label, String value, {bool isId = false}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
  color: Theme.of(context).colorScheme.primary.withAlpha(26),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w500,
                  color: isId 
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.onSurface,
                  letterSpacing: isId ? 0.5 : null,
                ),
          ),
        ),
      ],
    );
  }

  Widget _buildRolesSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Roles',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: employee.roles.map((role) => Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.secondaryContainer,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.verified_user,
                  size: 16,
                  color: Theme.of(context).colorScheme.onSecondaryContainer,
                ),
                const SizedBox(width: 6),
                Text(
                  role,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSecondaryContainer,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ],
            ),
          )).toList(),
        ),
      ],
    );
  }

  Widget _buildPermissionsSection(BuildContext context) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Permissions',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
      const SizedBox(height: 16),
      ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.3,
          minHeight: 200,
        ),
        child: ListView.builder(
          primary: true, // Uses PrimaryScrollController
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: permissions.length,
          itemBuilder: (context, index) {
            final permission = permissions[index];
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary.withAlpha(26),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.check_circle,
                      size: 16,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    permission,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    ],
  );
}
  Widget _buildActions(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FilledButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            icon: const Icon(Icons.close),
            label: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
class Employee {
  Employee(this.id, this.name, this.designation, this.salary, this.roles, this.permissions);

  final int id;
  final String name;
  final String designation;
  final int salary;
  final List<String> roles;
  final List<String> permissions;
}
class EmployeeNotifier extends AsyncNotifier<List<Employee>> {
  @override
  Future<List<Employee>> build() async {
    return getEmployeeData();
  }

  Future<void> reloadEmployees() async {
    state = const AsyncValue.loading();
    try {
      final employees = await getEmployeeData();
      state = AsyncValue.data(employees);
    } catch (error, stack) {
      state = AsyncValue.error(error, stack);
    }
  }

  Future<void> clearEmployees() async {
    state = const AsyncValue.loading();
    await Future.delayed(const Duration(milliseconds: 500));
    state = const AsyncValue.data([]);
  }
}

class PermissionsNotifier extends Notifier<AsyncValue<List<String>>> {
  int? employeeId;

  @override
  AsyncValue<List<String>> build() {
    return const AsyncValue.data([]);
  }

  Future<void> setEmployeeId(int id) async {
    employeeId = id;
    state = const AsyncValue.loading();
    try {
      final permissions = await fetchPermissions(id);
      state = AsyncValue.data(permissions);
    } catch (error, stack) {
      state = AsyncValue.error(error, stack);
    }
  }

  Future<List<String>> fetchPermissions(int employeeId) async {
    await Future.delayed(const Duration(seconds: 2));
    switch (employeeId) {
      case 10001:
        return ['Read', 'Write', 'Delete', 'Execute', 'Update', 'Create', 'Modify', 'Update', 'Create', 'Modify'];
      case 10002:
        return ['Read', 'Write', 'Execute'];
      case 10003:
        return ['Read', 'Write', 'Modify'];
      case 10004:
        return ['Read', 'Export', 'Import'];
      default:
        return ['No Permissions'];
    }
  }
}

final permissionsProvider = NotifierProvider<PermissionsNotifier, AsyncValue<List<String>>>(
  () => PermissionsNotifier(),
);

final employeeProvider = AsyncNotifierProvider<EmployeeNotifier, List<Employee>>(() {
  return EmployeeNotifier();
});


class MyHomePage extends ConsumerWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final employeeState = ref.watch(employeeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee Management'),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
      ),
      body: Column(
        children: [
          _buildActionButtons(context, ref),
          Expanded(
            child: employeeState.when(
              data: (employees) {
                if (employees.isEmpty) {
                  return _buildEmptyState(context);
                }
                return _buildDataGrid(context, employees, ref);
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stack) => Center(
                child: Text('Error: $error'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          FilledButton.icon(
            onPressed: () => ref.read(employeeProvider.notifier).clearEmployees(),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            icon: const Icon(Icons.clear_all),
            label: const Text('Clear All'),
          ),
          FilledButton.icon(
            onPressed: () => ref.read(employeeProvider.notifier).reloadEmployees(),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.secondary,
              foregroundColor: Theme.of(context).colorScheme.onSecondary,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            icon: const Icon(Icons.refresh),
            label: const Text('Reload Grid'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.info_outline,
            size: 30,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
          const SizedBox(height: 8),
          Text(
            'No Records Found',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ],
      ),
    );
  }

Widget _buildDataGrid(BuildContext context, List<Employee> employees, WidgetRef ref) {
  return SfDataGrid(
    source: EmployeeDataSource(
      context: context,
      employeeData: employees,
      onView: (employee) => _handleEmployeeView(context, employee, ref), // ref is available here
    ),
    columnWidthMode: ColumnWidthMode.fill,
    columns: _buildGridColumns(),
  );
}

  List<GridColumn> _buildGridColumns() {
    return <GridColumn>[
      GridColumn(
        columnName: 'id',
        label: Container(
          padding: const EdgeInsets.all(16.0),
          alignment: Alignment.center,
          child: const Text('ID'),
        ),
      ),
      GridColumn(
        columnName: 'name',
        label: Container(
          padding: const EdgeInsets.all(8.0),
          alignment: Alignment.center,
          child: const Text('Name'),
        ),
      ),
      GridColumn(
        columnName: 'designation',
        label: Container(
          padding: const EdgeInsets.all(8.0),
          alignment: Alignment.center,
          child: const Text('Designation', overflow: TextOverflow.ellipsis),
        ),
      ),
      GridColumn(
        columnName: 'salary',
        label: Container(
          padding: const EdgeInsets.all(8.0),
          alignment: Alignment.center,
          child: const Text('Salary'),
        ),
      ),
      GridColumn(
        columnName: 'action',
        label: Container(
          padding: const EdgeInsets.all(8.0),
          alignment: Alignment.center,
          child: const Text('Action'),
        ),
      ),
    ];
  }
  
//   Future<void> _handleEmployeeView(BuildContext context, Employee employee, WidgetRef ref) async {
//   try {
//     final completer = Completer<bool>();
    
//     // Show loading dialog
//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       builder: (dialogContext) => _buildLoadingDialog(
//         dialogContext,
//         () {
//           completer.complete(true); // Complete with true to indicate cancellation
//           Navigator.pop(dialogContext);
//         },
//       ),
//     );

//     // Fetch permissions and race with completer
//     final permissionsFuture = ref.read(permissionsProvider.notifier).fetchPermissions(employee.id);
//     final result = await Future.any([
//       permissionsFuture.then((permissions) => (cancelled: false, permissions: permissions)),
//       completer.future.then((cancelled) => (cancelled: true, permissions: <String>[]))
//     ]);
    
//     if (!result.cancelled && context.mounted) {
//       Navigator.pop(context); // Close loading dialog
      
//       // Show employee details dialog
//       await showDialog(
//         context: context,
//         builder: (context) => EmployeeDialog(
//           employee: employee,
//           permissions: result.permissions,
//         ),
//       );
//     }
//   } catch (e) {
//     if (context.mounted) {
//       Navigator.pop(context);
//       await showDialog(
//         context: context,
//         builder: (context) => ErrorDialog(
//           message: 'Failed to load permissions: ${e.toString()}',
//         ),
//       );
//     }
//   }
// }

Future<void> _handleEmployeeView(BuildContext context, Employee employee, WidgetRef ref) async {
  try {
    // Use LoadingHelper to show loading overlay
    final permissions = await LoadingHelper.withLoadingOverlay<List<String>>(
      context: context,
      message: 'Please wait while we fetch the permissions...',
      operation: () => ref.read(permissionsProvider.notifier).fetchPermissions(employee.id),
    );

    // Only show dialog if permissions were fetched (not cancelled)
    if (permissions != null && context.mounted) {
      await showDialog(
        context: context,
        builder: (context) => EmployeeDialog(
          employee: employee,
          permissions: permissions,
        ),
      );
    }
  } catch (e) {
    if (context.mounted) {
      ErrorHandler.showError(
        context, 
        'Failed to load permissions: ${e.toString()}'
      );
    }
  }
}


 Widget _buildLoadingDialog(BuildContext context, VoidCallback onCancel) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28.0),
      ),
      backgroundColor: Theme.of(context).colorScheme.surface,
      elevation: 8,
      child: Container(
        padding: const EdgeInsets.all(24.0),
        constraints: const BoxConstraints(
          minWidth: 280.0,
          maxWidth: 360.0,
          minHeight: 200.0,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 64,
              height: 64,
              child: CircularProgressIndicator(strokeWidth: 4),
            ),
            const SizedBox(height: 24),
            Text(
              'Loading Permissions',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 16),
            Text(
              'Please wait while we fetch the permissions...',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onCancel,
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error,
                foregroundColor: Theme.of(context).colorScheme.onError,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
              icon: const Icon(Icons.close),
              label: const Text('Cancel'),
            ),
          ],
        ),
      ),
    );
  }
}

// // Basic usage
// showDialog(
//   context: context,
//   builder: (context) => const ErrorDialog(
//     message: 'Something went wrong',
//   ),
// );

// // Custom title and message
// showDialog(
//   context: context,
//   builder: (context) => const ErrorDialog(
//     title: 'Permission Error',
//     message: 'You do not have permission to access this resource',
//     closeButtonText: 'Got it',
//   ),
// );

// // With callback
// showDialog(
//   context: context,
//   builder: (context) => ErrorDialog(
//     message: 'Network error occurred',
//     onClose: () {
//       // Do something after dialog is closed
//       print('Dialog closed');
//     },
//   ),
// );
class ErrorDialog extends StatelessWidget {
  final String title;
  final String message;
  final VoidCallback? onClose;
  final String closeButtonText;

  const ErrorDialog({
    super.key,
    this.title = 'Error',
    required this.message,
    this.onClose,
    this.closeButtonText = 'Close',
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      icon: Icon(
        Icons.error_outline,
        color: Theme.of(context).colorScheme.error,
        size: 32,
      ),
      title: Text(title),
      content: Text(
        message,
        style: Theme.of(context).textTheme.bodyLarge,
      ),
      actions: [
        FilledButton(
          onPressed: () {
            Navigator.of(context).pop();
            onClose?.call();
          },
          style: FilledButton.styleFrom(
            backgroundColor: Theme.of(context).colorScheme.error,
            foregroundColor: Theme.of(context).colorScheme.onError,
          ),
          child: Text(closeButtonText),
        ),
      ],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28),
      ),
      backgroundColor: Theme.of(context).colorScheme.surface,
      elevation: 8,
    );
  }
}

class EmployeeDataSource extends DataGridSource {
  final void Function(Employee) onView;
  final BuildContext context;

  EmployeeDataSource({
    required this.context,
    required List<Employee> employeeData,
    required this.onView,
  }) {
    _employeeData = employeeData.map<DataGridRow>(
      (employee) => DataGridRow(
        cells: [
          DataGridCell<int>(columnName: 'id', value: employee.id),
          DataGridCell<String>(columnName: 'name', value: employee.name),
          DataGridCell<String>(columnName: 'designation', value: employee.designation),
          DataGridCell<int>(columnName: 'salary', value: employee.salary),
          DataGridCell<Employee>(columnName: 'action', value: employee),
        ],
      ),
    ).toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: row.getCells().map<Widget>((cell) {
        if (cell.columnName == 'action') {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(8.0),
            child: IconButton(
              icon: Icon(Icons.visibility, color: Theme.of(context).colorScheme.primary),
              tooltip: 'View Details',
              onPressed: () {
                final employee = cell.value as Employee?;
                if (employee != null) {
                  onView(employee);
                }
              },
            ),
          );
        }
        return Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(8.0),
          child: Text(cell.value.toString()),
        );
      }).toList(),
    );
  }
}
class AppTheme {
  static ThemeData get light => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF1A73E8),
      brightness: Brightness.light,
    ),
    textTheme: Typography.material2021().black,
    cardTheme: const CardTheme(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(AppConstants.dialogBorderRadius),
        ),
      ),
    ),
    dialogTheme: const DialogTheme(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(AppConstants.dialogBorderRadius),
        ),
      ),
      elevation: 8,
    ),
  );

    static ThemeData get dark => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF1A73E8),
      brightness: Brightness.dark,
    ),
    textTheme: Typography.material2021().white,
    cardTheme: const CardTheme(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(AppConstants.dialogBorderRadius),
        ),
      ),
    ),
    dialogTheme: const DialogTheme(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(AppConstants.dialogBorderRadius),
        ),
      ),
      elevation: 8,
    ),
  );

}

class AppConstants {
  static const double dialogBorderRadius = 28.0;
  static const double buttonBorderRadius = 12.0;
  static const Duration loadingDelay = Duration(seconds: 2);
  static const Duration clearDelay = Duration(milliseconds: 500);
  
  static const double defaultPadding = 16.0;
  static const double defaultSpacing = 24.0;
}
class LoadingHelper {
  static bool _isLoading = false;
  static OverlayEntry? _currentOverlay;

  /// Shows a loading state as a regular widget
  static Widget buildLoadingState({String message = 'Loading...'}) {
    return LoadingState(message: message);
  }

  /// Executes an async operation with loading overlay
  static Future<T?> withLoadingOverlay<T>({
    required BuildContext context,
    required Future<T> Function() operation,
    String message = 'Processing...',
    Color? overlayColor,
    VoidCallback? onCancel,
  }) async {
    // Prevent multiple overlays
    if (_isLoading) return null;
    
    _isLoading = true;
    late OverlayEntry loadingEntry;
    bool isCancelled = false;
    
    // Create the loading state
    loadingEntry = OverlayEntry(
      builder: (context) => LoadingState(
        message: message,
        overlayColor: overlayColor ?? Colors.black54,
        onCancel: () {
          isCancelled = true;
          onCancel?.call();
          _removeOverlay(loadingEntry);
        },
      ),
    );
    
    // Store current overlay and show it
    _currentOverlay = loadingEntry;
    Overlay.of(context).insert(loadingEntry);
    
    try {
      final result = await operation();
      if (!isCancelled) {
        _removeOverlay(loadingEntry);
        return result;
      }
      return null;
    } catch (e) {
      if (!isCancelled) {
        _removeOverlay(loadingEntry);
      }
      rethrow;
    }
  }

  /// Safely removes the overlay entry and resets loading state
  static void _removeOverlay(OverlayEntry entry) {
    if (_currentOverlay == entry) {
      entry.remove();
      _currentOverlay = null;
      _isLoading = false;
    }
  }

  /// Forces cleanup of any stuck overlay
  static void forceCleanup() {
    if (_currentOverlay != null) {
      _currentOverlay!.remove();
      _currentOverlay = null;
    }
    _isLoading = false;
  }
}

class LoadingState extends StatelessWidget {
  final String? message;
  final bool showOverlay;
  final Color? overlayColor;
  final bool dismissible;
  final VoidCallback? onCancel;

  const LoadingState({
    super.key,
    this.message,
    this.showOverlay = true,
    this.overlayColor,
    this.dismissible = false,
    this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (showOverlay)
          ModalBarrier(
            color: overlayColor ?? 
    Theme.of(context).colorScheme.surface.withAlpha(204),
            dismissible: dismissible,
          ),
        Center(
          child: Container(
            padding: const EdgeInsets.all(24.0),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
color: Theme.of(context).colorScheme.shadow.withAlpha(26),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 48,
                  height: 48,
                  child: CircularProgressIndicator(strokeWidth: 3),
                ),
                if (message != null) ...[
                  const SizedBox(height: 16),
                  Text(
                    message!,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                  ),
                ],
                if (onCancel != null) ...[
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: onCancel,
                    child: const Text('Cancel'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}
class ErrorHandler {
  static void showError(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => ErrorDialog(message: message),
    );
  }
}
class MoneyFormatter {
  static String format(num value) {
    return '\$${value.toStringAsFixed(2)}';
  }
}
List<Employee> getEmployeeData() {
  return [
    Employee(10001, 'James', 'Project Lead', 20000, ['Admin'], ['Read', 'Write', 'Delete', 'Execute', 'Update', 'Create', 'Modify']),
    Employee(10002, 'Kathryn', 'Manager', 30000, ['Manager'], ['Read', 'Write']),
    Employee(10003, 'Lara', 'Developer', 15000, ['Developer'], ['Read', 'Write']),
    Employee(10004, 'Michael', 'Designer', 15000, ['Designer'], ['Read']),
  ];
}