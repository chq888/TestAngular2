import 'dart:async';

import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:async/async.dart'; // Import the async package

void main() {
  runApp(MyApp());
}

/// The application that contains the DataGrid.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Syncfusion DataGrid Demo',
      theme: ThemeData(
        useMaterial3: true, // Enable Material 3
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue), // Use Material 3 color scheme
        textTheme: Typography.material2021().black, // Use Material 3 typography
      ),
      home: MyHomePage(),
    );
  }
}
/// The home page of the application which hosts the DataGrid.
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Employee> employees = <Employee>[];
  late EmployeeDataSource employeeDataSource;
  Completer<void>? dialogCompleter; // Track the dialog state

  CancelableOperation<List<String>>? fetchPermissionsOperation;

  Future<List<String>> fetchPermissions(int employeeId) async {
  // Simulate a delay for fetching data
  await Future.delayed(Duration(seconds: 2));

  // Return permissions based on employee ID
  switch (employeeId) {
    case 10001:
      return ['Read', 'Write', 'Delete','Read', 'Write', 'Delete', 'Execute', 'Update', 'Create', 'Modify'];
    case 10002:
      return ['Read', 'Write', 'Execute'];
    case 10003:
      return ['Read', 'Write', 'Modify'];
    case 10004:
      return ['Read', 'Export', 'Import'];
    default:
      return ['No Permissions'];
  }
}

  @override
  void initState() {
    super.initState();
    employees = getEmployeeData();
    employeeDataSource = EmployeeDataSource(
      context: context,
      employeeData: employees,
onView: (employee) async {
  if (dialogCompleter != null && !dialogCompleter!.isCompleted) {
    return; // Prevent opening another dialog if one is already open
  }

  dialogCompleter = Completer<void>(); // Create a new Completer

  // Wrap the fetchPermissions call in a CancelableOperation
  fetchPermissionsOperation = CancelableOperation.fromFuture(
    fetchPermissions(employee.id),
    onCancel: () {
      print('Fetch permissions operation canceled.');
    },
  );

  // Show the dialog
 showDialog(
  context: context,
  barrierDismissible: false, // Prevent dismissing the dialog while loading
  builder: (BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Define responsive dialog dimensions
    final minDialogWidth = screenWidth * 0.5; // 50% of screen width (minimum)
    final minDialogHeight = screenHeight * 0.2; // 20% of screen height (minimum)
    final maxDialogWidth = screenWidth * 0.6; // 60% of screen width (maximum)
    final maxDialogHeight = screenHeight * 0.3; // 40% of screen height (maximum)

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28.0), // Material 3 rounded corners
      ),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minWidth: minDialogWidth,
          minHeight: minDialogHeight,
          maxWidth: maxDialogWidth,
          maxHeight: maxDialogHeight,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28.0), // Ensure scrollbar stays within rounded corners
          child: Scrollbar(
            thumbVisibility: true, // Always show scrollbar
            thickness: 6.0,
            radius: Radius.circular(8.0),
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: FutureBuilder<List<String>>(
                  future: fetchPermissionsOperation?.valueOrCancellation().then((value) => value ?? []) ?? Future.value([]),
                  builder: (BuildContext context, AsyncSnapshot<List<String>> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return buildLoadingDialogContent(context, () {
                        // Cancel the operation and close the dialog
                        fetchPermissionsOperation?.cancel();
                        dialogCompleter?.complete();
                        dialogCompleter = null;
                        Navigator.of(context).pop();
                      });
                    } else if (snapshot.hasError) {
                      return buildErrorDialogContent(
                        context,
                        'An error occurred while fetching permissions.', // Error message
                        () {
                          Navigator.of(context).pop(); // Close the dialog
                          dialogCompleter?.complete(); // Reset the Completer
                          dialogCompleter = null;
                        },
                      );
                    } else if (snapshot.data == null || snapshot.data!.isEmpty) {
                      // Handle cancellation or empty data
                      return Center(
                        child: Text('Operation canceled or no data available.'),
                      );
                    } else {
                      return _buildContentDialog(context, employee, snapshot.data ?? []);
                    }
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  },
)
  .then((_) {
    dialogCompleter?.complete(); // Mark the dialog as closed
    dialogCompleter = null; // Reset the Completer
  });
},
    );
  }

Widget buildLoadingDialogContent(BuildContext context, VoidCallback onCancel, {String message = 'Loading...'}) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Text(
        'Please Wait',
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 16),
      CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(
          Theme.of(context).colorScheme.primary,
        ),
      ),
      const SizedBox(height: 16),
      Text(
        message,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 24),
      FilledButton(
        onPressed: onCancel,
        style: FilledButton.styleFrom(
          backgroundColor: Theme.of(context).colorScheme.error,
          foregroundColor: Theme.of(context).colorScheme.onError,
        ),
        child: const Text('Cancel'),
      ),
    ],
  );
}
Widget buildErrorDialogContent(BuildContext context, String errorMessage, VoidCallback onClose) {
  return Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.error, color: Theme.of(context).colorScheme.error, size: 48),
        const SizedBox(height: 16),
        Text(
          errorMessage,
          style: Theme.of(context).textTheme.bodyMedium,
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: onClose,
          style: FilledButton.styleFrom(
            backgroundColor: Theme.of(context).colorScheme.primary,
            foregroundColor: Theme.of(context).colorScheme.onPrimary,
          ),
          child: const Text('Close'),
        ),
      ],
    ),
  );
}

Widget _buildContentDialog(BuildContext context, Employee employee, List<String> permissions) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(Icons.person, color: Theme.of(context).colorScheme.primary, size: 32),
          const SizedBox(width: 8),
          Text(
            'Employee Details',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      Divider(thickness: 1, color: Theme.of(context).colorScheme.onSurfaceVariant),
      const SizedBox(height: 16),
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailField(context, 'ID', '${employee.id}'),
                _buildDetailField(context, 'Name', employee.name),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailField(context, 'Designation', employee.designation),
                _buildDetailField(context, 'Salary', '\$${employee.salary}'),
              ],
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      Divider(thickness: 1, color: Theme.of(context).colorScheme.onSurfaceVariant),
      _buildPermissions(context, permissions),
      const SizedBox(height: 24),
      Align(
        alignment: Alignment.centerRight,
        child: FilledButton.icon(
          icon: const Icon(Icons.close),
          label: const Text('Close'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
    ],
  );
}
Widget _buildDetailField(BuildContext context, String label, String? value) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4.0),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$label: ',
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
        ),
        Expanded(
          child: Text(
            value ?? 'N/A',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ),
      ],
    ),
  );
}

Widget _buildPermissions(BuildContext context, List<String> permissions) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // Permissions Header
      Text(
        'Permissions',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
      const SizedBox(height: 8),
      // Permissions List
      ConstrainedBox(
        constraints: BoxConstraints(
          minWidth: double.infinity,
          minHeight: 100,
          maxHeight: MediaQuery.of(context).size.height * 0.2,
        ),
        child: Scrollbar(
          thumbVisibility: true,
          thickness: 6.0,
          radius: Radius.circular(8.0),
          child: ListView.builder(
            shrinkWrap: true,
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: permissions.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4.0),
                child: Row(
                  children: [
                    Icon(Icons.check, color: Theme.of(context).colorScheme.primary, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        permissions[index],
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    ],
  );
}
 @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: const Text('Syncfusion Flutter DataGrid'),
      centerTitle: true,
      backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
    ),
    body: Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: FilledButton(
            onPressed: () {
              employeeDataSource._employeeData = [];
              employeeDataSource.notifyListeners();
            },
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            child: const Text('Clear All'),
          ),
        ),
        Expanded(
          child: SfDataGrid(
            source: employeeDataSource,
            columnWidthMode: ColumnWidthMode.fill,
            placeholder: Center(
  child: Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Icon(Icons.info_outline, size: 30, color: Theme.of(context).colorScheme.onSurfaceVariant),
      const SizedBox(height: 8),
      Text(
        'No Records Found',
        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
      ),
    ],
  ),
),
            columns: <GridColumn>[
              GridColumn(
                columnName: 'id',
                label: Container(
                  padding: const EdgeInsets.all(16.0),
                  alignment: Alignment.center,
                  child: const Text('ID'),
                ),
              ),
              GridColumn(
                columnName: 'name',
                label: Container(
                  padding: const EdgeInsets.all(8.0),
                  alignment: Alignment.center,
                  child: const Text('Name'),
                ),
              ),
              GridColumn(
                columnName: 'designation',
                label: Container(
                  padding: const EdgeInsets.all(8.0),
                  alignment: Alignment.center,
                  child: const Text('Designation', overflow: TextOverflow.ellipsis),
                ),
              ),
              GridColumn(
                columnName: 'salary',
                label: Container(
                  padding: const EdgeInsets.all(8.0),
                  alignment: Alignment.center,
                  child: const Text('Salary'),
                ),
              ),
              GridColumn(
                columnName: 'action',
                label: Container(
                  padding: const EdgeInsets.all(8.0),
                  alignment: Alignment.center,
                  child: const Text('Action'),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

  List<Employee> getEmployeeData() {
    return [
    Employee(10001, 'James', 'Project Lead', 20000, ['Admin'], ['Read', 'Write', 'Delete', 'Execute', 'Update', 'Create', 'Modify']),
      Employee(10002, 'Kathryn', 'Manager', 30000, ['Manager'], ['Read', 'Write']),
      Employee(10003, 'Lara', 'Developer', 15000, ['Developer'], ['Read', 'Write']),
      Employee(10004, 'Michael', 'Designer', 15000, ['Designer'], ['Read']),
    ];
  }
}

/// Employee class to hold employee details.
class Employee {
  Employee(this.id, this.name, this.designation, this.salary, this.roles, this.permissions);

  final int id;
  final String name;
  final String designation;
  final int salary;
  final List<String> roles;
  final List<String> permissions;
}

/// Data source for the DataGrid.
class EmployeeDataSource extends DataGridSource {
  final void Function(Employee) onView;
  final BuildContext context;

  EmployeeDataSource({
    required this.context,
    required List<Employee> employeeData,
    required this.onView,
  }) {
    _employeeData = employeeData.map<DataGridRow>(
      (employee) => DataGridRow(
        cells: [
          DataGridCell<int>(columnName: 'id', value: employee.id),
          DataGridCell<String>(columnName: 'name', value: employee.name),
          DataGridCell<String>(columnName: 'designation', value: employee.designation),
          DataGridCell<int>(columnName: 'salary', value: employee.salary),
          DataGridCell<Employee>(columnName: 'action', value: employee),
        ],
      ),
    ).toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: row.getCells().map<Widget>((cell) {
        if (cell.columnName == 'action') {
          return Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(8.0),
            child: IconButton(
              icon: Icon(Icons.visibility, color: Theme.of(context).colorScheme.primary),
              tooltip: 'View Details',
              onPressed: () {
                final employee = cell.value as Employee?;
                if (employee != null) {
                  onView(employee);
                }
              },
            ),
          );
        }
        return Container(
          alignment: Alignment.center,
          padding: EdgeInsets.all(8.0),
          child: Text(cell.value.toString()),
        );
      }).toList(),
    );
  }
}