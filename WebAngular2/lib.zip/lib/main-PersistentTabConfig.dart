import 'package:equatable/equatable.dart';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Add this import for GoRouter and StatefulShellBranch
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:provider/provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

// Import your screen widgets
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // make navigation bar transparent
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  // make flutter draw behind navigation bar
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    runApp(
    const ProviderScope(
      child: PersistenBottomNavBarDemo(),
    ),
  );

}

class WebinarScreen extends StatelessWidget {
  const WebinarScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WebinarScreen'),
      ),
      body: const Center(
        child: Text('Welcome to the WebinarScreen!'),
      ),
    );
  }
}
class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Screen'),
      ),
      body: const Center(
        child: Text('Welcome to the Home Screen!'),
      ),
    );
  }
}
class MainScreen extends StatelessWidget {
  const MainScreen({super.key, this.useRouter = false});

  final bool useRouter;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text("Tab Main Screen")),
        backgroundColor: Colors.indigo,
        body: ListView(
          padding: const EdgeInsets.all(16)
              .copyWith(bottom: MediaQuery.of(context).padding.bottom),
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              child: TextField(
                decoration: InputDecoration(hintText: "Test Text Field"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (useRouter) {
                    context.go("/settings/detail");
                  } else {
                    pushScreen(
                      context,
                      withNavBar: true,
                      settings: const RouteSettings(name: "/home"),
                      screen: const MainScreen2(),
                      pageTransitionAnimation:
                          PageTransitionAnimation.scaleRotate,
                    );
                  }
                },
                child: const Text("Go to Second Screen with Navbar"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (useRouter) {
                    context.go("/home/detail");
                  } else {
                    pushScreen(
                      context,
                      settings: const RouteSettings(name: "/home"),
                      screen: const MainScreen2(),
                      pageTransitionAnimation:
                          PageTransitionAnimation.scaleRotate,
                    );
                  }
                },
                child: const Text("Go to Second Screen without Navbar"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    backgroundColor: Colors.white,
                    useRootNavigator: true,
                    builder: (context) => Center(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text("Exit"),
                      ),
                    ),
                  );
                },
                child: const Text("Push bottom sheet on TOP of Nav Bar"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    backgroundColor: Colors.white,
                    useRootNavigator: false,
                    builder: (context) => Center(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text("Exit"),
                      ),
                    ),
                  );
                },
                child: const Text("Push bottom sheet BEHIND the Nav Bar"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  pushWithNavBar(
                    context,
                    DialogRoute(
                      context: context,
                      builder: (context) => const ExampleDialog(),
                    ),
                  );
                },
                child: const Text("Push Dynamic/Modal Screen"),
              ),
            ),
          ],
        ),
      );
}

class MainScreen2 extends StatelessWidget {
  const MainScreen2({super.key, this.useRouter = false});

  final bool useRouter;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text("Secondary Screen")),
        backgroundColor: Colors.teal,
        body: ListView(
          padding: const EdgeInsets.all(16)
              .copyWith(bottom: MediaQuery.of(context).padding.bottom),
          children: <Widget>[
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (useRouter) {
                    context.go("/home/detail/super-detail");
                  } else {
                    pushScreen(
                      context,
                      screen: const MainScreen3(),
                      withNavBar: true,
                    );
                  }
                },
                child: const Text("Go to Third Screen with Navbar"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (useRouter) {
                    context.go("/detail/super-detail");
                  } else {
                    pushScreen(context, screen: const MainScreen3());
                  }
                },
                child: const Text("Go to Second Screen without Navbar"),
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Go Back to First Screen"),
              ),
            ),
          ],
        ),
      );
}

class MainScreen3 extends StatelessWidget {
  const MainScreen3({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text("Tertiary Screen")),
        backgroundColor: Colors.deepOrangeAccent,
        body: Center(
          child: ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text("Go Back to Second Screen"),
          ),
        ),
      );
}

class ExampleDialog extends StatelessWidget {
  const ExampleDialog({super.key});

  @override
  Widget build(BuildContext context) => Dialog(
        child: Container(
          height: MediaQuery.of(context).size.height * 0.6,
          width: MediaQuery.of(context).size.width * 0.3,
          padding: const EdgeInsets.symmetric(horizontal: 30),
          color: Colors.amber,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                "This is a modal screen",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 26,
                ),
              ),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text("Return"),
                ),
              ),
            ],
          ),
        ),
      );
}typedef NavBarBuilder = Widget Function(
  NavBarConfig,
  NavBarDecoration,
  ItemAnimation,
  NeumorphicProperties,
);

class Settings {
  bool hideNavBar = false;
  bool resizeToAvoidBottomInset = true;
  bool stateManagement = true;
  bool handleAndroidBackButtonPress = true;
  bool popAllScreensOnTapOfSelectedTab = true;
  bool avoidBottomPadding = true;
  Color navBarColor = Colors.white;
  NavBarBuilder get navBarBuilder => navBarStyles[navBarStyle]!;
  String navBarStyle = "Style 1";
  EdgeInsets margin = EdgeInsets.zero;

  Map<String, NavBarBuilder> navBarStyles = {
    "Neumorphic": (p0, p1, p2, p3) => NeumorphicBottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          neumorphicProperties: p3,
        ),
    "Style 1": (p0, p1, p2, p3) =>
        Style1BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
    "Style 2": (p0, p1, p2, p3) => Style2BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 3": (p0, p1, p2, p3) =>
        Style3BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
    "Style 4": (p0, p1, p2, p3) => Style4BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 5": (p0, p1, p2, p3) =>
        Style5BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
    "Style 6": (p0, p1, p2, p3) => Style6BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 7": (p0, p1, p2, p3) => Style7BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 8": (p0, p1, p2, p3) => Style8BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 9": (p0, p1, p2, p3) => Style9BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 10": (p0, p1, p2, p3) => Style10BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 11": (p0, p1, p2, p3) => Style11BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 12": (p0, p1, p2, p3) => Style12BottomNavBar(
          navBarConfig: p0,
          navBarDecoration: p1,
          itemAnimationProperties: p2,
        ),
    "Style 13": (p0, p1, p2, p3) =>
        Style13BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
    "Style 14": (p0, p1, p2, p3) =>
        Style14BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
    "Style 15": (p0, p1, p2, p3) =>
        Style15BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
    "Style 16": (p0, p1, p2, p3) =>
        Style16BottomNavBar(navBarConfig: p0, navBarDecoration: p1),
  };
}

class SettingsView extends StatefulWidget {
  const SettingsView({
    required this.settings,
    required this.onChanged,
    super.key,
  });

  final Settings settings;
  final void Function(Settings) onChanged;

  @override
  State<SettingsView> createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> {
  List<Color> colors = [
    Colors.white,
    Colors.black,
    Colors.red,
    Colors.green,
    Colors.blue,
    Colors.yellow,
    Colors.orange,
    Colors.purple,
    Colors.grey,
  ];

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButton<Color>(
                  value: widget.settings.navBarColor,
                  icon: const Icon(Icons.arrow_downward),
                  elevation: 16,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.navBarColor = value!;
                    });
                    widget.onChanged(widget.settings);
                  },
                  items: colors
                      .map<DropdownMenuItem<Color>>(
                        (value) => DropdownMenuItem<Color>(
                          value: value,
                          child: Container(
                            width: 25,
                            height: 25,
                            decoration: BoxDecoration(
                              color: value,
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 2,
                                  blurRadius: 2,
                                ),
                              ],
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                      )
                      .toList(),
                ),
                const Text("NavBar Color"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButton<String>(
                  value: widget.settings.navBarStyle,
                  icon: const Icon(Icons.arrow_downward),
                  elevation: 16,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.navBarStyle = value!;
                    });
                    widget.onChanged(widget.settings);
                  },
                  items: widget.settings.navBarStyles.keys
                      .map<DropdownMenuItem<String>>(
                        (value) => DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        ),
                      )
                      .toList(),
                ),
                const Text("NavBar Style"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("Margin LTRB:"),
                const SizedBox(width: 4),
                SizedBox(
                  width: 26,
                  child: TextFormField(
                    initialValue:
                        widget.settings.margin.left.toInt().toString(),
                    decoration: const InputDecoration(
                      isDense: true,
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.fromLTRB(4, 4, 4, 0),
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    onChanged: (value) {
                      setState(() {
                        widget.settings.margin = widget.settings.margin
                            .copyWith(left: double.tryParse(value) ?? 0);
                      });
                      widget.onChanged(widget.settings);
                    },
                  ),
                ),
                const SizedBox(width: 4),
                SizedBox(
                  width: 26,
                  child: TextFormField(
                    initialValue: widget.settings.margin.top.toInt().toString(),
                    decoration: const InputDecoration(
                      isDense: true,
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.fromLTRB(4, 4, 4, 0),
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    onChanged: (value) {
                      setState(() {
                        widget.settings.margin = widget.settings.margin
                            .copyWith(top: double.tryParse(value) ?? 0);
                      });
                      widget.onChanged(widget.settings);
                    },
                  ),
                ),
                const SizedBox(width: 4),
                SizedBox(
                  width: 26,
                  child: TextFormField(
                    initialValue:
                        widget.settings.margin.right.toInt().toString(),
                    decoration: const InputDecoration(
                      isDense: true,
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.fromLTRB(4, 4, 4, 0),
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    onChanged: (value) {
                      setState(() {
                        widget.settings.margin = widget.settings.margin
                            .copyWith(right: double.tryParse(value) ?? 0);
                      });
                      widget.onChanged(widget.settings);
                    },
                  ),
                ),
                const SizedBox(width: 4),
                SizedBox(
                  width: 26,
                  child: TextFormField(
                    initialValue:
                        widget.settings.margin.bottom.toInt().toString(),
                    decoration: const InputDecoration(
                      isDense: true,
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.fromLTRB(4, 4, 4, 0),
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    onChanged: (value) {
                      setState(() {
                        widget.settings.margin = widget.settings.margin
                            .copyWith(bottom: double.tryParse(value) ?? 0);
                      });
                      widget.onChanged(widget.settings);
                    },
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Switch(
                  value: widget.settings.hideNavBar,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.hideNavBar = value;
                    });
                    widget.onChanged(widget.settings);
                  },
                ),
                const Text("Hide Navigation Bar"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Switch(
                  value: widget.settings.resizeToAvoidBottomInset,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.resizeToAvoidBottomInset = value;
                    });
                    widget.onChanged(widget.settings);
                  },
                ),
                const Text("Resize to avoid bottom inset"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Switch(
                  value: widget.settings.stateManagement,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.stateManagement = value;
                    });
                    widget.onChanged(widget.settings);
                  },
                ),
                const Text("State Management"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Switch(
                  value: widget.settings.handleAndroidBackButtonPress,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.handleAndroidBackButtonPress = value;
                    });
                    widget.onChanged(widget.settings);
                  },
                ),
                const Text("Handle Android Back Button Press"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Switch(
                  value: widget.settings.popAllScreensOnTapOfSelectedTab,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.popAllScreensOnTapOfSelectedTab = value;
                    });
                    widget.onChanged(widget.settings);
                  },
                ),
                const Text("Pop all screens when\ntapping current tab"),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Switch(
                  value: widget.settings.avoidBottomPadding,
                  onChanged: (value) {
                    setState(() {
                      widget.settings.avoidBottomPadding = value;
                    });
                    widget.onChanged(widget.settings);
                  },
                ),
                const Text("Avoid bottom padding"),
              ],
            ),
          ],
        ),
      );
}class InteractiveExample extends StatefulWidget {
  const InteractiveExample({super.key});

  @override
  State<InteractiveExample> createState() => _InteractiveExampleState();
}

class _InteractiveExampleState extends State<InteractiveExample> {
  final PersistentTabController _controller = PersistentTabController();
  Settings settings = Settings();

  List<PersistentTabConfig> _tabs() => [
        PersistentTabConfig(
          screen: const MainScreen(),
          item: ItemConfig(
            icon: const Icon(Icons.home),
            title: "Home",
            activeForegroundColor: Colors.blue,
            inactiveForegroundColor: Colors.grey,
          ),
        ),
        PersistentTabConfig(
          screen: const MainScreen(),
          item: ItemConfig(
            icon: const Icon(Icons.search),
            title: "Search",
            activeForegroundColor: Colors.teal,
            inactiveForegroundColor: Colors.grey,
          ),
        ),
        PersistentTabConfig.noScreen(
          item: ItemConfig(
            icon: const Icon(Icons.add),
            title: "Add",
            activeForegroundColor: Colors.blueAccent,
            inactiveForegroundColor: Colors.grey,
          ),
          onPressed: (context) {
            pushWithNavBar(
              context,
              DialogRoute(
                context: context,
                builder: (context) => const ExampleDialog(),
              ),
            );
          },
        ),
        PersistentTabConfig(
          screen: const MainScreen(),
          item: ItemConfig(
            icon: const Icon(Icons.message),
            title: "Messages",
            activeForegroundColor: Colors.deepOrange,
            inactiveForegroundColor: Colors.grey,
          ),
        ),
        PersistentTabConfig(
          screen: const MainScreen(),
          item: ItemConfig(
            icon: const Icon(Icons.settings),
            title: "Settings",
            activeForegroundColor: Colors.indigo,
            inactiveForegroundColor: Colors.grey,
          ),
        ),
      ];

  @override
  Widget build(BuildContext context) => PersistentTabView(
        controller: _controller,
        tabs: _tabs(),
        navBarBuilder: (navBarConfig) => settings.navBarBuilder(
          navBarConfig,
          NavBarDecoration(
            color: settings.navBarColor,
            borderRadius: BorderRadius.circular(10),
          ),
          const ItemAnimation(),
          const NeumorphicProperties(),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => showDialog(
            context: context,
            builder: (context) => Dialog(
              child: SettingsView(
                settings: settings,
                onChanged: (newSettings) => setState(() {
                  settings = newSettings;
                }),
              ),
            ),
          ),
          child: const Icon(Icons.settings),
        ),
        backgroundColor: Colors.green,
        margin: settings.margin,
        avoidBottomPadding: settings.avoidBottomPadding,
        handleAndroidBackButtonPress: settings.handleAndroidBackButtonPress,
        resizeToAvoidBottomInset: settings.resizeToAvoidBottomInset,
        stateManagement: settings.stateManagement,
        onWillPop: (context) async {
          await showDialog(
            context: context,
            builder: (context) => Dialog(
              child: Center(
                child: ElevatedButton(
                  child: const Text("Close"),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),
            ),
          );
          return false;
        },
        hideNavigationBar: settings.hideNavBar,
        popAllScreensOnTapOfSelectedTab:
            settings.popAllScreensOnTapOfSelectedTab,
      );
}class GoRouterExample extends StatelessWidget {
  GoRouterExample({super.key});

  final _parentKey = GlobalKey<NavigatorState>();
  final _shellKey = GlobalKey<NavigatorState>();

  final subRoutes = GoRoute(
    path: "detail",
    builder: (context, state) => const MainScreen2(
      useRouter: true,
    ),
    routes: [
      GoRoute(
        path: "super-detail",
        builder: (context, state) => const MainScreen3(),
      ),
    ],
  );

  late final GoRouter goRouter = GoRouter(
    /// If you want the app to start on the first tab use this:
    // initialLocation: "/home",
    navigatorKey: _parentKey,
    routes: [
      GoRoute(
        path: "/",
        builder: (context, state) => Material(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ElevatedButton(
                  onPressed: () => context.go("/home"),
                  child: const Text("Show Router Example"),
                ),
                const SizedBox(height: 16),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 32),
                  child: Text(
                    "This screen could be something you require the user to do before entering the main app content (like a login form)",
                  ),
                ),
              ],
            ),
          ),
        ),
        routes: [
          StatefulShellRoute.indexedStack(
            builder: (context, state, navigationShell) =>
                PersistentTabView.router(
              tabs: [
                PersistentRouterTabConfig(
                  item: ItemConfig(
                    icon: const Icon(Icons.home),
                    title: "Home",
                  ),
                ),
                PersistentRouterTabConfig(
                  item: ItemConfig(
                    icon: const Icon(Icons.message),
                    title: "Messages",
                  ),
                ),
                PersistentRouterTabConfig(
                  item: ItemConfig(
                    icon: const Icon(Icons.settings),
                    title: "Settings",
                  ),
                ),
              ],
              navBarBuilder: (navBarConfig) => Style1BottomNavBar(
                navBarConfig: navBarConfig,
              ),
              navigationShell: navigationShell,
            ),
            branches: [
              // The route branch for the 1st Tab
              StatefulShellBranch(
                navigatorKey: _shellKey,
                routes: <RouteBase>[
                  GoRoute(
                    path: "home",
                    builder: (context, state) => const MainScreen(
                      useRouter: true,
                    ),
                    routes: [
                      /// When you use the navigator Key that of the root navigator, this and all the sub routes will be pushed to the root navigator (-> without the navbar)
                      GoRoute(
                        parentNavigatorKey: _parentKey,
                        path: "detail",
                        builder: (context, state) => const MainScreen2(
                          useRouter: true,
                        ),
                        routes: [
                          GoRoute(
                            path: "super-detail",
                            builder: (context, state) => const MainScreen3(),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),

              // The route branch for 2nd Tab
              StatefulShellBranch(
                routes: <RouteBase>[
                  GoRoute(
                    path: "messages",
                    builder: (context, state) => const MainScreen(
                      useRouter: true,
                    ),
                    routes: [subRoutes],
                  ),
                ],
              ),

              // The route branch for 3rd Tab
              StatefulShellBranch(
                routes: <RouteBase>[
                  GoRoute(
                    path: "settings",
                    builder: (context, state) => const MainScreen(
                      useRouter: true,
                    ),
                    routes: [subRoutes],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    ],
  );

  @override
  Widget build(BuildContext context) => MaterialApp.router(
        title: "Persistent Bottom Navigation Bar Demo",
        routerConfig: goRouter,
      );
}
class PersistenBottomNavBarDemo extends StatelessWidget {
  const PersistenBottomNavBarDemo({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: "Persistent Bottom Navigation Bar Demo",
        home: Builder(
          builder: (context) => Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pushNamed("/minimal"),
                  child: const Text("Show Minimal Example"),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () =>
                      Navigator.of(context).pushNamed("/interactive"),
                  child: const Text("Show Interactive Example"),
                ),
              ],
            ),
          ),
        ),
        routes: {
          "/minimal": (context) => const MinimalExample(),
          "/interactive": (context) => const InteractiveExample(),
        },
      );
}

// class MinimalExample extends StatelessWidget {
//   const MinimalExample({super.key});

//   List<PersistentTabConfig> _tabs() => [
//         PersistentTabConfig(
//           screen: const MainScreen(),
//           item: ItemConfig(
//             icon: const Icon(Icons.home),
//             title: "Home",
//           ),
//         ),
//         PersistentTabConfig(
//           screen: const MainScreen(),
//           item: ItemConfig(
//             icon: const Icon(Icons.message),
//             title: "Messages",
//           ),
//         ),
//         PersistentTabConfig(
//           screen: const MainScreen(),
//           item: ItemConfig(
//             icon: const Icon(Icons.settings),
//             title: "Settings",
//           ),
//         ),
//       ];

//   @override
//   Widget build(BuildContext context) 
//   {
// return PersistentTabView(
//         tabs: _tabs(),
//         navBarBuilder: (navBarConfig) => Style1BottomNavBar(
//           navBarConfig: navBarConfig,
//         ),
//       );
//   } 
// }

// First, create a state notifier for managing tabs
// Replace StateNotifierProvider with NotifierProvider
final tabsProvider = NotifierProvider<TabsNotifier, List<PersistentTabConfig>>(() {
  return TabsNotifier();
});

// Update TabsNotifier to extend Notifier instead of StateNotifier
class TabsNotifier extends Notifier<List<PersistentTabConfig>> {
  @override
  List<PersistentTabConfig> build() {
    return _createInitialTabs();
  }

  List<PersistentTabConfig> _createInitialTabs() => [
    PersistentTabConfig(
      screen: const MainScreen(),
      item: ItemConfig(
        icon: const Icon(Icons.home),
        title: "Home",
      ),
    ),
    PersistentTabConfig(
      screen: const MainScreen(),
      item: ItemConfig(
        icon: const Icon(Icons.message),
        title: "Messages",
      ),
    ),
    PersistentTabConfig(
      screen: const MainScreen(),
      item: ItemConfig(
        icon: const Icon(Icons.settings),
        title: "Settings",
      ),
    ),
  ];

  void addNewTab() {
    state = [
      ...state,
      PersistentTabConfig(
        screen: const MainScreen(),
        item: ItemConfig(
          icon: const Icon(Icons.add),
          title: "New Tab",
        ),
      ),
    ];
  }
  
  void removeNewTab() {
    state = [
      PersistentTabConfig(
        screen: const MainScreen(),
        item: ItemConfig(
          icon: const Icon(Icons.add),
          title: "New Tab",
        ),
      ),
    ];
  }
}
// Then update MinimalExample to use Riverpod
class MinimalExample extends ConsumerWidget {
  const MinimalExample({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tabs = ref.watch(tabsProvider);
    final tabsNotifier = ref.read(tabsProvider.notifier);

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () => tabsNotifier.addNewTab(),
        child: const Icon(Icons.add),
      ),
      body: PersistentTabView(
        key: ValueKey(tabs.map((tab) => tab.item.title).join('')),
        tabs: tabs,
        navBarBuilder: (navBarConfig) => Style1BottomNavBar(
          navBarConfig: navBarConfig,
        ),
      ),
    );
  }
}

// class MinimalExample extends StatefulWidget {
//   const MinimalExample({super.key});

//   @override
//   State<MinimalExample> createState() => _MinimalExampleState();
// }

// class _MinimalExampleState extends State<MinimalExample> {
//   // Value notifier for tabs
//   final _tabsNotifier = ValueNotifier<List<PersistentTabConfig>>([]);
  
//   @override
//   void initState() {
//     super.initState();
//     // Initialize tabs
//     _tabsNotifier.value = _createTabs();
//   }

//   @override
//   void dispose() {
//     _tabsNotifier.dispose();
//     super.dispose();
//   }

//   List<PersistentTabConfig> _createTabs() => [
//     PersistentTabConfig(
//       screen: const MainScreen(),
//       item: ItemConfig(
//         icon: const Icon(Icons.home),
//         title: "Home",
//       ),
//     ),
//     PersistentTabConfig(
//       screen: const MainScreen(),
//       item: ItemConfig(
//         icon: const Icon(Icons.message),
//         title: "Messages",
//       ),
//     ),
//     PersistentTabConfig(
//       screen: const MainScreen(),
//       item: ItemConfig(
//         icon: const Icon(Icons.settings),
//         title: "Settings",
//       ),
//     ),
//   ];

//   void _updateTabs() {
//     // Example of dynamically changing tabs
//     _tabsNotifier.value = [
//       ..._tabsNotifier.value,
//       PersistentTabConfig(
//         screen: const MainScreen(),
//         item: ItemConfig(
//           icon: const Icon(Icons.add),
//           title: "New Tab",
//         ),
//       ),
//     ];
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       floatingActionButton: FloatingActionButton(
//         onPressed: _updateTabs,
//         child: const Icon(Icons.add),
//       ),
//       body: ValueListenableBuilder<List<PersistentTabConfig>>(
//         valueListenable: _tabsNotifier,
//         builder: (context, tabs, _) {
//           return PersistentTabView(
//             // Add unique key to force rebuild
//             key: ValueKey(tabs.length),
//             tabs: tabs,
//             navBarBuilder: (navBarConfig) => Style1BottomNavBar(
//               navBarConfig: navBarConfig,
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

final bottomTabsProvider = StateNotifierProvider<BottomTabsController, BottomTabsState>((ref) {
  return BottomTabsController();
});

class BottomTabsState {
  final List<KTab> tabs;
  final bool showBottomTabbar;
  final int currentIndex;

  const BottomTabsState({
    this.tabs = const [],
    this.showBottomTabbar = true,
    this.currentIndex = 0,
  });

  BottomTabsState copyWith({
    List<KTab>? tabs,
    bool? showBottomTabbar,
    int? currentIndex,
  }) {
    return BottomTabsState(
      tabs: tabs ?? this.tabs,
      showBottomTabbar: showBottomTabbar ?? this.showBottomTabbar,
      currentIndex: currentIndex ?? this.currentIndex,
    );
  }
}

class MainScreen22 extends ConsumerWidget {
  const MainScreen22({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // final tabsController = ref.watch(bottomTabsProvider.notifier);
    // final tabsState = ref.watch(bottomTabsProvider);

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Exit App?'),
            content: const Text('Do you want to exit the app?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Exit'),
              ),
            ],
          ),
        );
        if (shouldPop ?? false) {
          return;
        }
      },
      child: PersistentTabView(
        backgroundColor: Colors.red,
        tabs: _tabs(),
        navBarBuilder: (navBarConfig) => Style1BottomNavBar(
          navBarConfig: navBarConfig,
          navBarDecoration: NavBarDecoration(color: Colors.transparent),
        ),
        navBarOverlap: NavBarOverlap.full(),
      ),
    );
  }

    List<PersistentTabConfig> _tabs() => [
        PersistentTabConfig(
          screen: const MainScreen(),
          item: ItemConfig(
            activeForegroundColor: Colors.white,
            inactiveBackgroundColor: Colors.white,
            icon: const Icon(Icons.home),
            title: "Home",
          ),
        ),
        PersistentTabConfig(
          screen: const HomeScreen(),
          item: ItemConfig(
            icon: const Icon(Icons.message),
            title: "Messages",
          ),
        ),
        PersistentTabConfig(
          screen: const MainScreen(),
          item: ItemConfig(
            icon: const Icon(Icons.settings),
            title: "Settings",
          ),
        ),
      ];


}

class BottomTabsController extends StateNotifier<BottomTabsState> {
  final _tabController = PersistentTabController();
  
  BottomTabsController() : super(const BottomTabsState());

  void initScreens({bool showWebinar = false}) {
    final newTabs = [
      KTab.home,
      if (showWebinar) KTab.webinar,
    ];
    
    state = state.copyWith(tabs: newTabs);
    _tabController.jumpToTab(0);
  }

  List<BottomTab> get tabs => state.tabs.map((val) => BottomTab.fromEnum(val)).toList();

  PersistentTabController get tabController => _tabController;

  void changePage(KTab tab) {
    final tabIndex = state.tabs.indexOf(tab);
    if (tabIndex != -1 && tabIndex != state.currentIndex) {
      _tabController.jumpToTab(tabIndex);
      state = state.copyWith(currentIndex: tabIndex);
    }
  }

  void drawerChanged(bool isOpened) {
    state = state.copyWith(showBottomTabbar: !isOpened);
  }
}

// class BottomTabsController extends ChangeNotifier {
//   final PersistentTabController tabController = PersistentTabController();
//   bool showBottonTabbar = true;
//   final List<KTab> _tabseq = [];

//   void initScreens({bool showWebinar = false}) {
//     _tabseq.clear();
//     _tabseq.addAll([
//       KTab.home,
//       if (showWebinar) KTab.webinar,
//     ]);
//     notifyListeners();
//   }

//   List<BottomTab> get tabs => _tabseq.map((val) => BottomTab.fromEnum(val)).toList();

//   KTab get currentTab => _tabseq[tabController.index];

//   void changePage(KTab tab) {
//     if (tab == currentTab) return;
//     final tabIndex = _tabseq.indexOf(tab);
//     if (tabIndex != -1) {
//       tabController.jumpToTab(tabIndex);
//     }
//   }

//   void drawerChanged(bool isOpened) {
//     showBottonTabbar = !isOpened;
//     notifyListeners();
//   }
// }



class BottomTab extends Equatable {
  final Widget? icon;
  final String name;
  final KTab tabEnum;
  final Widget screen;

  const BottomTab({
    this.icon,
    required this.name,
    required this.tabEnum,
    required this.screen,
  });

  factory BottomTab.fromEnum(KTab val) {
    switch (val) {
      case KTab.home:
        return const BottomTab(
          icon: Icon(Icons.home_rounded),
          name: 'Home',
          tabEnum: KTab.home,
          screen: HomeScreen(),
        );
      case KTab.webinar:
        return const BottomTab(
          icon: Icon(Icons.video_camera_front),
          name: 'Webinar',
          tabEnum: KTab.webinar,
          screen: WebinarScreen(),
        );
      case KTab.android:
        return const BottomTab(
          icon: Icon(Icons.android),
          name: 'Android',
          tabEnum: KTab.android,
          screen: WebinarScreen(),
        );
      case KTab.ios:
        return const BottomTab(
          icon: Icon(Icons.phone_iphone),
          name: 'iOS',
          tabEnum: KTab.ios,
          screen: WebinarScreen(),
        );
      case KTab.web:
        return const BottomTab(
          icon: Icon(Icons.web),
          name: 'Web',
          tabEnum: KTab.web,
          screen: HomeScreen(),
        );
      case KTab.windows:
        return const BottomTab(
          icon: Icon(Icons.desktop_windows),
          name: 'Windows',
          tabEnum: KTab.windows,
          screen: HomeScreen(),
        );
    }
  }

  @override
  List<Object?> get props => [tabEnum];
}

// class BottomTabsController extends ChangeNotifier {
//   final PersistentTabController tabController = PersistentTabController();
//   bool showBottonTabbar = true;
//   final List<KTab> _tabseq = [];

//   void initScreens({bool showWebinar = false}) {
//     _tabseq.clear();
//     _tabseq.addAll([
//       KTab.home,
//       if (showWebinar) KTab.webinar,
//     ]);
//     notifyListeners();
//   }

//   List<BottomTab> get tabs => _tabseq.map((val) => BottomTab.fromEnum(val)).toList();

//   KTab get currentTab => _tabseq[tabController.index];

//   void changePage(KTab tab) {
//     if (tab == currentTab) return;
//     final tabIndex = _tabseq.indexOf(tab);
//     if (tabIndex != -1) {
//       tabController.jumpToTab(tabIndex);
//     }
//   }

//   void drawerChanged(bool isOpened) {
//     showBottonTabbar = !isOpened;
//     notifyListeners();
//   }
// }

// class BottomTabsController extends ChangeNotifier {
//   PersistentTabController tabController = PersistentTabController();

//   bool showBottonTabbar = true;

//   void initScreens({bool showIOS = true}) {
//     _tabseq.clear();
//     _tabseq.addAll([
//       KTab.home,
//       if (showIOS) KTab.webinar,
//       // KTab.windows,
//     ]);
//   }

//   final List<KTab> _tabseq = [];

//   List<BottomTab> get tabs {
//     List<BottomTab> tablist = [];

//     for (final val in _tabseq) {
//       tablist.add(BottomTab.fromEnum(val));
//     }

//     return tablist;
//   }

//   KTab get currentTab {
//     return _tabseq[tabController.index];
//   }

//   void changePage(KTab tab) {
//     if (tab == currentTab) {
//       return;
//     }

//     final tabIndex = _tabseq.indexOf(tab);

//     tabController.jumpToTab(tabIndex);
//   }

//   void drawerChanged(bool isOpened) {
//     if (isOpened) {
//       showBottonTabbar = false;
//     } else {
//       showBottonTabbar = true;
//     }
//     notifyListeners();
//   }
// }

// Removed duplicate BottomTab class definition to resolve the conflict.

enum KTab {
  android,
  ios,
  web,
  windows,
  home,
  webinar
}

// The issue is in 
// initScreen Method when the tabs are added using addAll() > PersistentTabViewScaffold (shouldBuildTab.addAll())