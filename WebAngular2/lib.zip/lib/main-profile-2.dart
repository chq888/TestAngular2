import 'package:equatable/equatable.dart';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Add this import for GoRouter and StatefulShellBranch
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:provider/provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


// Import your screen widgets
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // make navigation bar transparent
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  // make flutter draw behind navigation bar
   SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    runApp(
    const ProviderScope(
      child: MyApp (),
    ),
  );


}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    final userProfile = UserProfile(
  firstName: 'John',
  lastName: 'Doe',
  userName: 'johndoe',
  email: 'john.doe@example.com',
  age: 30,
  birthday: DateTime(1993, 5, 15),
  address: '123 Main St, City, Country',
  phone: '+1 234 567 8900',
  photoUrl: 'https://example.com/photo.jpg',
  company: CompanyInfo(
    name: 'Tech Corp',
    position: 'Senior Software Engineer',
    roles: List.generate(10, (index) => CompanyRole(
      role: 'Role ${index + 1}',
      permissions: List.generate(20, (i) => 'Permission ${i + 1}'),
    )),
  ),
);


    return MaterialApp(
      title: 'Syncfusion DataGrid Demo',
      theme: ThemeData(
        useMaterial3: true, // Enable Material 3
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue), // Use Material 3 color scheme
        textTheme: Typography.material2021().black, // Use Material 3 typography
      ),
      home: ProfileScreen(user: userProfile),
    );
  }
}


class UserProfile {
  final String firstName;
  final String lastName;
  final String userName;
  final String email;
  final int age;
  final DateTime birthday;
  final String address;
  final String phone;
  final String? photoUrl;
  final CompanyInfo company;

  const UserProfile({
    required this.firstName,
    required this.lastName,
    required this.userName,
    required this.email,
    required this.age,
    required this.birthday,
    required this.address,
    required this.phone,
    this.photoUrl,
        required this.company,

  });

  String get fullName => '$firstName $lastName';
}
class CompanyRole {
  final String role;
  final List<String> permissions;

  const CompanyRole({
    required this.role,
    required this.permissions,
  });
}

class CompanyInfo {
  final String name;
  final String position;
  final List<CompanyRole> roles;

  const CompanyInfo({
    required this.name,
    required this.position,
    required this.roles,
  });
}


class ProfileScreen extends StatelessWidget {
  final UserProfile user;

  const ProfileScreen({
    super.key,
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildProfileHeader(context),
          const SizedBox(height: 24),
          _buildDetailsSection(context),
          const SizedBox(height: 24),
          _buildCompanyRolesSection(context),
        ],
      ),
    ),
    );
  }

  Widget _buildProfileHeader(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 50,
          backgroundImage: user.photoUrl != null 
              ? NetworkImage(user.photoUrl!) 
              : null,
          child: user.photoUrl == null 
              ? Text(
                  user.firstName[0] + user.lastName[0],
                  style: Theme.of(context).textTheme.headlineMedium,
                )
              : null,
        ),
        const SizedBox(height: 16),
        Text(
          user.fullName,
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        Text(
          user.email,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      ],
    );
  }

  Widget _buildDetailsSection(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Personal Information',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            _buildDetailRow('Username', user.userName),
            _buildDetailRow('Age', user.age.toString()),
            _buildDetailRow(
              'Birthday', 
              DateFormat('MMMM d, y').format(user.birthday),
            ),
            _buildDetailRow('Phone', user.phone),
            _buildDetailRow('Address', user.address),
          ],
        ),
      ),
    );
  }

Widget _buildCompanyRolesSection(BuildContext context) {
  return Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user.company.name,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user.company.position,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
              CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                child: Text(
                  user.company.name[0],
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
                ),
              ),
            ],
          ),
          const Divider(height: 32),
          Text(
            'Roles & Permissions',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 16),
          ...user.company.roles.map((role) => _buildRoleCard(context, role)),
        ],
      ),
    ),
  );
}
Widget _buildRoleCard(BuildContext context, CompanyRole role) {
  return Card(
    margin: const EdgeInsets.only(bottom: 8),
    elevation: 0,
    clipBehavior: Clip.antiAlias, // Add smooth clipping for expansion
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8),
      side: BorderSide(
        color: Theme.of(context).colorScheme.outlineVariant,
        width: 0.5, // Thinner border
      ),
    ),
    child: ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), // Reduced padding
      childrenPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(6), // Smaller icon container
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(
          Icons.workspace_premium,
          color: Theme.of(context).colorScheme.primary,
          size: 18, // Smaller icon
        ),
      ),
      title: Text(
        role.role,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w500,
          fontSize: 14, // Smaller text
        ),
      ),
      subtitle: Text(
        '${role.permissions.length} permissions',
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
          fontSize: 12, // Smaller text
        ),
      ),
      children: [
        Divider(
          height: 1,
          thickness: 0.5, // Thinner divider
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
        LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth > 600 ? 3 : 2;
            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.all(12), // Reduced padding
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                childAspectRatio: 8, // More compact ratio
                mainAxisSpacing: 6, // Reduced spacing
                crossAxisSpacing: 12,
              ),
              itemCount: role.permissions.length,
              itemBuilder: (context, index) {
                final permission = role.permissions[index];
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), // Reduced padding
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceVariant.withAlpha(50),
                    borderRadius: BorderRadius.circular(4), // Smaller radius
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.check_circle,
                        color: Theme.of(context).colorScheme.primary,
                        size: 14, // Smaller icon
                      ),
                      const SizedBox(width: 6), // Reduced spacing
                      Expanded(
                        child: Text(
                          permission,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontSize: 12, // Smaller text
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ],
    ),
  );
}


Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}// Example usage in your app
