import 'package:equatable/equatable.dart';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Add this import for GoRouter and StatefulShellBranch
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:provider/provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


// Import your screen widgets
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // make navigation bar transparent
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  // make flutter draw behind navigation bar
   SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    runApp(
    const ProviderScope(
      child: MyApp (),
    ),
  );


}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    final userProfile = UserProfile(
  firstName: 'John',
  lastName: 'Doe',
  userName: 'johndoe',
  email: 'john.doe@example.com',
  age: 30,
  birthday: DateTime(1993, 5, 15),
  address: '123 Main St, City, Country',
  phone: '+1 234 567 8900',
  photoUrl: 'https://example.com/photo.jpg',
  companies: [
    CompanyInfo(
      name: 'Tech Corp',
      position: 'Senior Software Engineer',
      roles: List.generate(5, (index) => CompanyRole(
        role: 'Role ${index + 1}',
        permissions: List.generate(10, (i) => 'Permission ${i + 1}'),
      )),
    ),
    CompanyInfo(
      name: 'Innovate Inc',
      position: 'Technical Consultant',
      roles: List.generate(5, (index) => CompanyRole(
        role: 'Consultant Role ${index + 1}',
        permissions: List.generate(10, (i) => 'Consultant Permission ${i + 1}'),
      )),
    ),
  ],
);


    return MaterialApp(
      title: 'User Profile',
      theme: ThemeData(
        useMaterial3: true, // Enable Material 3
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        cardTheme: CardTheme(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          scrolledUnderElevation: 0,
        ),
        dividerTheme: const DividerThemeData(
          space: 20,
          thickness: 0.5,
        ),
      ),
      home: ProfileScreen(user: userProfile),
    );
  }
}


class UserProfile {
  final String firstName;
  final String lastName;
  final String userName;
  final String email;
  final int age;
  final DateTime birthday;
  final String address;
  final String phone;
  final String? photoUrl;
  final List<CompanyInfo> companies;

  const UserProfile({
    required this.firstName,
    required this.lastName,
    required this.userName,
    required this.email,
    required this.age,
    required this.birthday,
    required this.address,
    required this.phone,
    this.photoUrl,
    required this.companies,
  });

  String get fullName => '$firstName $lastName';
  
  // Get the current/primary company (first in the list)
  CompanyInfo get primaryCompany => companies.first;
}
class CompanyRole {
  final String role;
  final List<String> permissions;

  const CompanyRole({
    required this.role,
    required this.permissions,
  });
}

class CompanyInfo {
  final String name;
  final String position;
  final List<CompanyRole> roles;

  const CompanyInfo({
    required this.name,
    required this.position,
    required this.roles,
  });
}


class ProfileScreen extends StatelessWidget {
  final UserProfile user;

  const ProfileScreen({
    super.key,
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    // Get screen size for responsive design
    final screenSize = MediaQuery.of(context).size;
    final isSmallScreen = screenSize.width < 600;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: TextStyle(fontWeight: FontWeight.w600)),
        scrolledUnderElevation: 0,
        backgroundColor: Theme.of(context).colorScheme.surface,
        actions: [
          IconButton(
            icon: Icon(Icons.edit_outlined),
            onPressed: () {
              // Edit profile functionality would go here
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Edit profile functionality'))
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.settings_outlined),
            onPressed: () {
              // Settings functionality would go here
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Settings functionality'))
              );
            },
          ),
        ],
      ),
      body: 
        SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildProfileHeader(context, isSmallScreen),
              const SizedBox(height: 24),
              _buildUserDetailsSection(context, isSmallScreen),
              const SizedBox(height: 24),
              _buildCompanyRolesSection(context, isSmallScreen),
            ],
          ),
        ),
    );
  }

  // Profile header with photo, name and basic info
  Widget _buildProfileHeader(BuildContext context, bool isSmallScreen) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 0,
      color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.7),
      clipBehavior: Clip.antiAlias,
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primaryContainer,
              Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.8),
            ],
            stops: const [0.3, 1.0],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 28.0, horizontal: 24.0),
          child: isSmallScreen
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildAvatar(context),
                    const SizedBox(height: 16),
                    _buildHeaderInfo(context),
                  ],
                )
              : Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildAvatar(context),
                    const SizedBox(width: 24),
                    Expanded(child: _buildHeaderInfo(context)),
                  ],
                ),
        ),
      ),
    );
  }

  // Avatar widget with placeholder if no photo URL
  Widget _buildAvatar(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: Theme.of(context).colorScheme.surface,
          width: 4,
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).colorScheme.shadow.withOpacity(0.2),
            blurRadius: 8,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: CircleAvatar(
        radius: 56,
        backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
        backgroundImage: user.photoUrl != null
            ? NetworkImage(user.photoUrl!)
            : null,
        child: user.photoUrl == null
            ? Text(
                user.firstName[0] + user.lastName[0],
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              )
            : null,
      ),
    );
  }

  // Header info with name, username, and position
  Widget _buildHeaderInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          user.fullName,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onPrimaryContainer,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          '@${user.userName}',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.8),
              ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Icon(
              Icons.business,
              size: 18,
              color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.8),
            ),
            const SizedBox(width: 8),
            Text(
              '${user.primaryCompany.name} • ${user.primaryCompany.position}',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _buildInfoChip(context, user.email, Icons.email_outlined),
            _buildInfoChip(context, user.phone, Icons.phone_outlined),
          ],
        ),
      ],
    );
  }

  // User details section with all personal information
  Widget _buildUserDetailsSection(BuildContext context, bool isSmallScreen) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(context, 'Personal Information', Icons.person_outline),
            const SizedBox(height: 20),
            isSmallScreen
                ? Column(
                    children: _buildDetailItems(context),
                  )
                : Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          children: _buildDetailItems(context).sublist(0, 4),
                        ),
                      ),
                      const SizedBox(width: 24),
                      Expanded(
                        child: Column(
                          children: _buildDetailItems(context).sublist(4),
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  // Generate list of detail items for user information
  List<Widget> _buildDetailItems(BuildContext context) {
    final formatter = DateFormat('MMMM d, yyyy');
    
    final details = [
      {'First Name': user.firstName},
      {'Last Name': user.lastName},
      {'Username': user.userName},
      {'Email': user.email},
      {'Age': user.age.toString()},
      {'Birthday': formatter.format(user.birthday)},
      {'Address': user.address},
      {'Phone': user.phone},
    ];
    
    return details.map((detail) => _buildDetailItem(context, detail)).toList();
  }

  // Individual detail item with label and value
  Widget _buildDetailItem(BuildContext context, Map<String, String> detail) {
    final entry = detail.entries.first;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            entry.key,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            entry.value,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
          ),
          const SizedBox(height: 8),
          Divider(height: 1, thickness: 0.5),
        ],
      ),
    );
  }

  // Section header with icon and title
  Widget _buildSectionHeader(BuildContext context, String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).colorScheme.primary,
            size: 22,
          ),
        ),
        const SizedBox(width: 16),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                letterSpacing: -0.5,
              ),
        ),
      ],
    );
  }

  // Info chip for contact information
  Widget _buildInfoChip(BuildContext context, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withOpacity(0.7),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 16,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ],
      ),
    );
  }

  // Company roles section with expandable role cards
  Widget _buildCompanyRolesSection(BuildContext context, bool isSmallScreen) {
    return Card(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(context, 'Roles & Permissions', Icons.admin_panel_settings_outlined),
            const SizedBox(height: 12),
            // Companies tabs
            ...user.companies.map((company) => _buildCompanySection(context, company, isSmallScreen)),
          ],
        ),
      ),
    );
  }
  
  // Individual company section with its roles
  Widget _buildCompanySection(BuildContext context, CompanyInfo company, bool isSmallScreen) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Company info card
        Container(
          margin: const EdgeInsets.only(top: 8, bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.4),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.business_outlined,
                  color: Theme.of(context).colorScheme.secondary,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      company.name,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    Text(
                      company.position,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // Roles list
        ...company.roles.map((role) => _buildRoleCard(context, role, isSmallScreen)),
        // Add divider between companies
        if (company != user.companies.last)
          Divider(height: 32, thickness: 1, color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5)),
      ],
    );
  }

  // Individual role card with expandable permissions list
  Widget _buildRoleCard(BuildContext context, CompanyRole role, bool isSmallScreen) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          width: 0.5,
        ),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        childrenPadding: EdgeInsets.zero,
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primaryContainer,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Icon(
            Icons.workspace_premium,
            color: Theme.of(context).colorScheme.primary,
            size: 18,
          ),
        ),
        title: Text(
          role.role,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
        ),
        subtitle: Text(
          '${role.permissions.length} permissions',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontSize: 12,
              ),
        ),
        children: [
          Divider(height: 1, thickness: 0.5),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: _buildPermissionsGrid(context, role.permissions, isSmallScreen),
          ),
        ],
      ),
    );
  }

  // Grid of permissions with responsive columns
  Widget _buildPermissionsGrid(BuildContext context, List<String> permissions, bool isSmallScreen) {
    final columns = isSmallScreen ? 2 : 3;
    
    // Calculate the aspect ratio to ensure items are 30px high
    // First get available width after padding
    final availableWidth = MediaQuery.of(context).size.width - 64; // accounting for padding
    // Width per item
    final itemWidth = (availableWidth / columns) - 8; // subtracting crossAxisSpacing
    // Calculate aspect ratio (width / height)
    final aspectRatio = itemWidth / 30.0; // 30px height
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        childAspectRatio: aspectRatio,  // Dynamic aspect ratio for 30px height
        mainAxisSpacing: 6,   // Reduced spacing
        crossAxisSpacing: 8,  // Reduced spacing
      ),
      itemCount: permissions.length,
      itemBuilder: (context, index) {
        return _buildPermissionItem(context, permissions[index]);
      },
    );
  }

  // Individual permission item with check icon
  Widget _buildPermissionItem(BuildContext context, String permission) {
    return Container(
      height: 30, // Fixed height of 30px
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(8),  // More rounded corners for Material 3
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.3),
          width: 0.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center, // Center vertically
        children: [
          Icon(
            Icons.check_circle_rounded, // More rounded icon for Material 3
            color: Theme.of(context).colorScheme.primary,
            size: 14,  // Slightly larger for better visibility
          ),
          const SizedBox(width: 4),  // Reduced spacing
          Expanded(
            child: Text(
              permission,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontSize: 12,  // Smaller text
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }
}
